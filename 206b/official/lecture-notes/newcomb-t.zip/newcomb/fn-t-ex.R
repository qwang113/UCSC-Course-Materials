### functions to sample each parameter from its full conditionals
### y_i \mid mu, V_i \iid N(\mu, V_i)
### V_i \mid sig2 \iid Inv-chsq(\nu, sig2)
### p(\mu, \sig2) \propto 1/sig2

### update V_i
fn_update_V <- function(n, nu, sig2, y_mu_sq)
{
    V <- 1.0/rgamma(n, (nu + 1.0)/2.0, (y_mu_sq + nu*sig2)/2.0)  ## so mean b/(a-1)
    return(V)
}

### update sig2
fn_update_sig2 <- function(n, nu, V)
{
    sig2 <- rgamma(1, (n*nu)/2, nu/2*sum(1.0/V))  ## mean a/b
    return(sig2)
    
}

## udpate mu
fn_update_mu <- function(V, Y)
{
    va <- 1.0/sum(1.0/V)
    mm <- va*sum(Y/V)
    
    mu <- rnorm(1, mm, sqrt(va))
    return(mu)
    
}

