rm(list=ls(all=TRUE))
set.seed(454)


## install package that include the datasets in BDA
### install.packages("BayesDA")
library(BayesDA)

### load dataset "light" into the workspace
data(light)
comment(light)

Dat <- NULL
Dat$N <- length(light)
Dat$y <- light

### MCMC iterations
n_sam <- 15000

## hyperparameter
hyper <- NULL
hyper$nu <- 3  ## df for t

## initial values
cur_sam <- NULL
cur_sam$mu <- mean(Dat$y)
cur_sam$sig2 <- var(Dat$y)
cur_sam$V <- rep(1, Dat$N)


### save simulated para
SAVE_MCMC_sam <- NULL
SAVE_MCMC_sam$mu <- rep(NA, n_sam)
SAVE_MCMC_sam$sig2 <- rep(NA, n_sam)
SAVE_MCMC_sam$V <- array(NA, dim=c(Dat$N, n_sam))

## read in source file to sample para from their full conditionals
source("fn-t-ex.R")

## RUN MCMC - all Gibbs steps!
for(i_iter in 1:n_sam)
{
    if((i_iter%%1000)==0)
    {
        print(paste("i.iter=", i_iter))
        print(date())
    }
    
    ## udpate V
    cur_sam$V <- fn_update_V(Dat$N, hyper$nu, cur_sam$sig2, (Dat$y- cur_sam$mu)^2)
    
    ## update sig2
    cur_sam$sig2 <- fn_update_sig2(Dat$N, hyper$nu, cur_sam$V)
    
    
    ## udpate mu
    cur_sam$mu <- fn_update_mu(cur_sam$V, Dat$y)
    
    
    ## save cur_sam
    SAVE_MCMC_sam$V[,i_iter] <- cur_sam$V
    SAVE_MCMC_sam$sig2[i_iter] <- cur_sam$sig2
    SAVE_MCMC_sam$mu[i_iter] <- cur_sam$mu
}## for(i_iter in 1:n_sam)


### check convergence and mixing
pdf("t-model/trace-mu.pdf", width=10, height=4)
par(mar=c(4.5, 4.5, 2.1, 2.1))
plot(SAVE_MCMC_sam$mu, xlab="iter", ylab="mu", cex.axis=2, cex.lab=2)
dev.off()

pdf("t-model/trace-sig2.pdf", width=10, height=4)
par(mar=c(4.5, 4.5, 2.1, 2.1))
plot(SAVE_MCMC_sam$sig2, xlab="iter", ylab="sig2", cex.axis=2, cex.lab=2)
dev.off()


pdf("t-model/trace-V.pdf", width=10, height=4)
par(mar=c(4.5, 4.5, 2.1, 2.1), mfrow=c(2, 1))
for(i in 1:Dat$N)
{
    plot(SAVE_MCMC_sam$V[i,], xlab="iter", ylab="V_i", main=i, cex.axis=2, cex.lab=2)
}
dev.off()



## summarize the posterior
inf_sam <- seq(5001, n_sam, by=2)  ## burn in first 5000 iterations and take every other after burn-in

print(round(quantile(SAVE_MCMC_sam$mu[inf_sam], prob=c(0.025, 0.5, 0.975)), 3))
print(round(mean(SAVE_MCMC_sam$mu[inf_sam]), 3))

print(round(quantile(SAVE_MCMC_sam$sig2[inf_sam], prob=c(0.025, 0.5, 0.975)), 3))
print(round(mean(SAVE_MCMC_sam$sig2[inf_sam]), 3))


pdf("t-model/post-mu.pdf")
par(mar=c(4.5, 4.5, 2.1, 2.1))
hist(SAVE_MCMC_sam$mu[inf_sam], xlab="mu", cex.axis=2, cex.lab=2, nclass=20, main="", prob="TRUE")
abline(v=c(quantile(SAVE_MCMC_sam$mu[inf_sam], prob=c(0.025, 0.5, 0.975))), col=2, lty=2, lwd=3)
abline(v=mean(SAVE_MCMC_sam$mu[inf_sam]), col=4, lty=3, lwd=3)
dev.off()


pdf("t-model/post-sig2.pdf")
par(mar=c(4.5, 4.5, 2.1, 2.1))
hist(SAVE_MCMC_sam$sig2[inf_sam], xlab="sig2", cex.axis=2, cex.lab=2, nclass=20, main="", prob="TRUE")
abline(v=c(quantile(SAVE_MCMC_sam$sig2[inf_sam], prob=c(0.025, 0.5, 0.975))), col=2, lty=2, lwd=3)
abline(v=mean(SAVE_MCMC_sam$sig2[inf_sam]), col=4, lty=3, lwd=3)
dev.off()



### posterior predictive distribution
set.seed(871432)
y_pred <- rt(length(inf_sam), hyper$nu)*sqrt(SAVE_MCMC_sam$sig2[inf_sam]) + SAVE_MCMC_sam$mu[inf_sam]

pdf("t-model/pred-y.pdf")
par(mar=c(4.5, 4.5, 2.1, 2.1))
hist(y_pred, xlab="y_future", cex.axis=2, cex.lab=2, nclass=50, main="", prob="TRUE", ylim=c(0, 0.10))
abline(v=c(quantile(y_pred, prob=c(0.025, 0.5, 0.975))), col=2, lty=2, lwd=3)
abline(v=mean(y_pred), col=4, lty=3, lwd=3)

hist(Dat$y, lwd=4, cex.axis=2, cex.lab=2, prob="TRUE", add=T, col=rgb(1,0,0,0.5), nclass=20)
dev.off()


print(round(quantile(y_pred, prob=c(0.025, 0.5, 0.975)), 3))
print(round(mean(y_pred), 3))



pdf("t-model/pred-y-1.pdf")
par(mar=c(4.5, 4.5, 2.1, 2.1))
hist(y_pred, xlab="y_future", cex.axis=2, cex.lab=2, nclass=50, main="", prob="TRUE", ylim=c(0, 0.10), xlim=c(-45, 50))
abline(v=c(quantile(y_pred, prob=c(0.025, 0.5, 0.975))), col=2, lty=2, lwd=3)
abline(v=mean(y_pred), col=4, lty=3, lwd=3)

hist(Dat$y, lwd=4, cex.axis=2, cex.lab=2, prob="TRUE", add=T, col=rgb(1,0,0,0.5), nclass=20)
dev.off()

