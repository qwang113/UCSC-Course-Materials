rm(list=ls(all=TRUE))  ## clean up the workspace
set.seed(8147)  ## set the random seed

##%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
### BEGIN: Define functions that I need
## update theta -- theta | n, lambda \sim Binom(n, \lambda)
fn_update_th <- function(n, p)
{
    new_th <- rbinom(1, n, p)
    return(new_th)
}

## update lam -- lam | x, th, n \sim Be(\theta + \alpha, n - \theta + \beta)
fn_update_lam <- function(a, b)
{
    new_lam <- rbeta(1, a, b)
    return(new_lam)
}

## update n -- (n-th) | x, th, lam \sim Poi(xi(1-lam))
fn_update_n <- function(a)
{
    new_n <- rpois(1, a)
    return(new_n)
}

fn_run_burn <- function(cur_sam, n_burn, hyper)
{
    for(i_iter in 1:n_burn)
    {
        ## draw theta given data and all other parameters
        cur_sam$th <- fn_update_th(cur_sam$n, cur_sam$lam)
        
        ## draw lam given data and all other parameters
        cur_sam$lam <- fn_update_lam(cur_sam$th + hyper$alpha, cur_sam$n - cur_sam$th + hyper$beta)
        
        ## draw n given data and all other parameters
        cur_sam$n <- fn_update_n(hyper$xi*(1 - cur_sam$lam)) + cur_sam$th
    }
    return(cur_sam)
}

fn_run_inf <- function(cur_sam, n_sam, hyper)
{
    ### save MCMC sample
    save_sam <- NULL
    save_sam$th <- save_sam$lam <- save_sam$n <- rep(NA, N_sam)
    
    for(i_iter in 1:n_sam)
    {
        ## draw theta given data and all other parameters
        cur_sam$th <- fn_update_th(cur_sam$n, cur_sam$lam)
        
        ## draw lam given data and all other parameters
        cur_sam$lam <- fn_update_lam(cur_sam$th + hyper$alpha, cur_sam$n - cur_sam$th + hyper$beta)
        
        ## draw n given data and all other parameters
        cur_sam$n <- fn_update_n(hyper$xi*(1 - cur_sam$lam)) + cur_sam$th
        
        ## save current values
        save_sam$th[i_iter] <- cur_sam$th
        save_sam$lam[i_iter] <- cur_sam$lam
        save_sam$n[i_iter] <- cur_sam$n
    }
    
    return(save_sam)
}
##%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
### END: Define functions that I need
##%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

#############################################################
### specify values needed -- alpha, beta (which are functions of data)
hpara <- NULL
hpara$xi <- 50  ## hyperaparameter
hpara$alpha <- 3.4
hpara$beta <- 5.2
#############################################################
N <- 5000 ## sample size

### set the initial values
ini_sam <- NULL
ini_sam$th <- 4
ini_sam$lam <- 0.1
ini_sam$n <- ini_sam$th + 5

#### MCMC parameters
N_burn <- 5000
N_sam <- 8000
N_thin <- 2

## run MC for burn-in period
ini_sam_1 <- fn_run_burn(ini_sam, N_burn, hpara)

## run MC to draw samples after burn-in period
my_sam <- fn_run_inf(ini_sam_1, N_sam, hpara)

my_sam$th <- my_sam$th[seq(1, N_sam, by=N_thin)]
my_sam$lam <- my_sam$lam[seq(1, N_sam, by=N_thin)]
my_sam$n <- my_sam$n[seq(1, N_sam, by=N_thin)]



post_th <- table(c(my_sam$th, (min(my_sam$th):max(my_sam$th)))) - 1
post_th <- post_th/length(my_sam$th)

pdf("hist-th.pdf")
par(mar=c(4.5, 4.5, 2.1, 2.1))
hist(my_sam$th, xlab="theta", main="", cex.axis=2, cex.lab=2, lwd=4, prob=TRUE, ylim=c(0, 0.05))
points((min(my_sam$th):max(my_sam$th)), post_th, lwd=2, col=2)
lines((min(my_sam$th):max(my_sam$th)), post_th, lwd=1, col=2, lty=3)
abline(v=c(mean(my_sam$th), quantile(my_sam$th, prob=c(0.025, 0.975))), col=2, lwd=4, lty=2)
dev.off()



pdf("hist-lam.pdf")
par(mar=c(4.5, 4.5, 2.1, 2.1))
hist(my_sam$lam, xlab="lambda", main="", cex.axis=2, cex.lab=2, lwd=4)
abline(v=c(mean(my_sam$lam), quantile(my_sam$lam, prob=c(0.025, 0.975))), col=2, lwd=4, lty=2)
dev.off()


post_n <- table(c(my_sam$n, (min(my_sam$n):max(my_sam$n)))) - 1
post_n <- post_n/length(my_sam$n)

pdf("hist-n.pdf")
par(mar=c(4.5, 4.5, 2.1, 2.1))
hist(my_sam$n, xlab="n", main="", cex.axis=2, cex.lab=2, lwd=4, prob=TRUE, ylim=c(0, 0.067))
points((min(my_sam$n):max(my_sam$n)), post_n, lwd=2, col=2)
lines((min(my_sam$n):max(my_sam$n)), post_n, lwd=1, col=2, lty=3)
abline(v=c(mean(my_sam$n), quantile(my_sam$n, prob=c(0.025, 0.975))), col=2, lwd=4, lty=2)
dev.off()


pdf("plot-th-n.pdf")
par(mar=c(4.5, 4.5, 2.1, 2.1))
plot(jitter(my_sam$n), jitter(my_sam$th), xlab="n", ylab="theta", main="", cex.axis=2, cex.lab=2, lwd=1.2)
points(mean(my_sam$n), mean(my_sam$th), col=2, lwd=4, cex=2, pch=4)
dev.off()


pdf("plot-th-lam.pdf")
par(mar=c(4.5, 4.5, 2.1, 2.1))
plot(my_sam$lam, jitter(my_sam$th), xlab="lambda", ylab="theta", main="", cex.axis=2, cex.lab=2, lwd=4)
points(mean(my_sam$lam), mean(my_sam$th), col=2, lwd=4, cex=2, pch=4)
dev.off()



pdf("plot-n-lam.pdf")
par(mar=c(4.5, 4.5, 2.1, 2.1))
plot(my_sam$lam, jitter(my_sam$n), xlab="lambda", ylab="n", main="", cex.axis=2, cex.lab=2, lwd=4)
points(mean(my_sam$lam), mean(my_sam$n), col=2, lwd=4, cex=2, pch=4)
dev.off()


