rm(list=ls(all=TRUE))
set.seed(4554)

###### Simulate data#################
## x_i \iid Weibull(\alpha, \eta)  #####################
### f(x) \propto \alpha \eta x^{\alpha-1} \exp(-x^\alpha \eta)
tr_alpha <- 1
tr_eta <- 0.5

##
# if \alpha=1, it becomes Exp(eta) with mean 1/eta and var 1/eta^2
###  ===> E(x) = 2 \& Var(x)=4
##

n <- 100
x <- rweibull(n, shape=tr_alpha, scale=(1/tr_eta)^tr_alpha)


###### Specify hyperparameters #################
hpara <- NULL

### \alpha \sim \Exp(1)
hpara$a <- 1

#### eta \sim \Ga(\beta, \xi) with prior mean \beta/\xi
hpara$beta <- 1
hpara$xi <- 0.01

################################################
## random walk M-H
################################################
M <- 10000 ### Monte Carlo sample size

th_sam <- NULL
th_sam$alpha <- rep(NA, M)
th_sam$eta <- rep(NA, M)

###### Proposal density: q(\theta^\prime \mid \theta)  #################
## Let q(\theta^\prime \mid \theta) = \Nor(0, v^2)  #####################
v <- c(0.05, 0.1)

### starting value
a_cur <- 1
e_cur <- 1

sum_log_x <- sum(log(x))

### iterate M times
for(i_iter in 1:M)
{
    ## propose a value, xi using the proposal distribution
    a_pro <- exp(log(a_cur) + rnorm(1, 0, v[1]))
    e_pro <- exp(log(e_cur) + rnorm(1, 0, v[2]))
    
    ## compute the acceptance prob.
    ### evaluate with the proposed value
    rho_pro <- n*log(a_pro) + n*log(e_pro) + (a_pro-1)*sum_log_x - e_pro*sum(x^a_pro) # the likelihood
    rho_pro <- rho_pro - hpara$a*a_pro + log(a_pro) + hpara$beta*log(e_pro) - hpara$xi*e_pro ### prior + Jacobian
    
    ### evaluate with the current value
    rho_cur <- n*log(a_cur) + n*log(e_cur) + (a_cur-1)*sum_log_x - e_cur*sum(x^a_cur) #the likelihood
    rho_cur <- rho_cur - hpara$a*a_cur + log(a_cur) + hpara$beta*log(e_cur) - hpara$xi*e_cur ### prior + Jacobian
    
    if(log(runif(1)) < (rho_pro - rho_cur))  ## accept w/p rho
    {
        a_cur <- a_pro
        e_cur <- e_pro
    }
    
    ### save the current value
    th_sam$alpha[i_iter] <- a_cur
    th_sam$eta[i_iter] <- e_cur
}## for(i_iter in 1:M)


pdf("MH-W-trace1.pdf")
par(mar=c(4.5, 4.5, 2.1, 2.1))
plot(th_sam$alpha, type="l", ylab="alpha", xlab="Iterations", cex.axis=2, cex.lab=2)
abline(h=tr_alpha, col=2, lwd=2)
dev.off()

pdf("MH-W-trace2.pdf")
par(mar=c(4.5, 4.5, 2.1, 2.1))
plot(th_sam$eta, type="l", ylab="eta", xlab="Iterations", cex.axis=2, cex.lab=2)
abline(h=tr_eta, col=2, lwd=2)
dev.off()


#####################################
Burn <- 4000
thin <- 2

### samples that will be used for inference
a_sam <- th_sam$alpha[seq(Burn+1, M, by=thin)]
e_sam <- th_sam$eta[seq(Burn+1, M, by=thin)]
#####################################

### summaries of the margianl posterior of alpha
post_m_a <- mean(a_sam)
post_sd_a <- sd(a_sam)
ci_a <- quantile(a_sam, prob=c(0.025, 0.975))
post_m_a
post_sd_a
ci_a

### summaries of the margianl posterior of eta
post_m_e <- mean(e_sam)
post_sd_e <- sd(e_sam)
ci_e <- quantile(e_sam, prob=c(0.025, 0.975))
post_m_e
post_sd_e
ci_e



pdf("MH-W-a.pdf")
par(mar=c(4.5, 4.5, 2.1, 2.1))
hist(a_sam, lwd=4, xlab="theta", cex.axis=2, cex.lab=2)
abline(v=tr_alpha, col=2, lwd=2)
abline(v=c(ci_a, post_m_a), col=4, lwd=2, lty=2)
dev.off()

pdf("MH-W-e.pdf")
par(mar=c(4.5, 4.5, 2.1, 2.1))
hist(e_sam, lwd=4, xlab="theta", cex.axis=2, cex.lab=2)
abline(v=tr_eta, col=2, lwd=2)
abline(v=c(ci_e, post_m_e), col=4, lwd=2, lty=2)
dev.off()


###%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
#%%% Make a plot of the joint posterior of alpha and eta
library(MASS)
z <- kde2d(a_sam, e_sam, n=50)

pdf("MH-W-joint.pdf")
par(mar=c(4.5, 4.5, 2.1, 2.1))
plot(cbind(a_sam, e_sam), xlab="Alpha", ylab="Eta", pch=19, cex=0.4, cex.axis=2, cex.lab=2)
contour(z, drawlabels=FALSE, nlevels=10, add=TRUE, lwd=1.5)
abline(h=post_m_e, v=post_m_a, lwd=2, lty=2, col=4)
abline(h=tr_eta, v=tr_alpha, lwd=2, col=2)
dev.off()

###%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
#%%%## preditive distribution
y <- rweibull(length(a_sam), shape=a_sam, scale=(1/e_sam)^a_sam)
mean(y)
sd(y)
quantile(y, prob=c(0.025, 0.975))

pdf("MH-W-y.pdf")
par(mar=c(4.5, 4.5, 2.1, 2.1))
hist(y, lwd=4, xlab="y", cex.axis=2, cex.lab=2)
abline(v=c(mean(y), quantile(y, prob=c(0.025, 0.975))), col=4, lwd=2, lty=2)
dev.off()







