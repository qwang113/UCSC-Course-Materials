rm(list=ls(all=TRUE))  ## clean up the workspace
set.seed(8147)  ## set the random seed

#############################################################
N <- 10
sig2 <- 9
x <- rnorm(N, 0, sqrt(sig2))
## generate my data from N(\theta=0, \sig2)
## Assume the true value of \theta is 0 but unknown to us
## We use N(\mu, \tau2) as the prior for \theta
## \sig2, \mu and \tau2 are fixed
#############################################################


###  Suppose we set \mu=0 and \sig2=1 => \theta \sim N(0, 1)
mu <- 0
tau2 <- 2

post_m <- 1/(N/sig2 + 1/tau2)*(mean(x)*N/sig2 + mu/tau2)
post_m

post_var <- 1/(N/sig2 + 1/tau2)
post_var


c(post_m, post_var)

pred_m <- post_m
pred_var <- post_var + sig2


c(post_m, post_var)
c(pred_m, pred_var)

n_sam <- 10000
th_sam <- rnorm(n_sam, post_m, sqrt(post_var))
x_new <- rnorm(n_sam, th_sam, sqrt(sig2))


th_grid <- seq(-3.5, 3.5, by=0.1)
den_post <- dnorm(th_grid, post_m, sqrt(post_var))



pdf("th-post.pdf")
par(mar=c(4.5, 4.5, 2.1, 2.1))
hist(th_sam, col="grey", xlab="theta", main="", cex.axis=2, cex.lab=2, lwd=4, probability=TRUE)
lines(th_grid, den_post, col=2, lwd=3, lty=2)
dev.off()

mean(th_sam); post_m
quantile(th_sam, prob=c(0.025, 0.5, 0.975))
qnorm(c(0.025, 0.5, 0.975), post_m, sqrt(post_var))
var(th_sam); post_var



pdf("th-abs-post.pdf")
par(mar=c(4.5, 4.5, 2.1, 2.1))
hist(abs(th_sam), col="grey", xlab="abs(theta)", main="", cex.axis=2, cex.lab=2, lwd=4, probability=TRUE)
#lines(th_grid, den_post, col=2, lwd=3, lty=2)
dev.off()

mean(abs(th_sam));
quantile(abs(th_sam), prob=c(0.025, 0.5, 0.975))
var(abs(th_sam));






x_grid <- seq(-6, 6, by=0.1)
den_pred <- dnorm(x_grid, pred_m, sqrt(pred_var))


pdf("x-pred.pdf")
par(mar=c(4.5, 4.5, 2.1, 2.1))
hist(x_new, col="grey", xlab="x", main="", cex.axis=2, cex.lab=2, lwd=4, probability=TRUE)
lines(x_grid, den_pred, col=2, lwd=3, lty=2)
dev.off()

mean(x_new); pred_m
quantile(x_new, prob=c(0.025, 0.5, 0.975))
qnorm(c(0.025, 0.5, 0.975), pred_m, sqrt(pred_var))
var(x_new); pred_var

