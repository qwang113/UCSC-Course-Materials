rm(list=ls(all=TRUE))
set.seed(454)

###### Target density (stationary density of Markov Chain): \pi(\theta)  #################
## Let \pi(\theta) = \IG(a, b) with mean b/(a-1)  #####################
a <- 3
b <- 3

th_grid <- seq(0.01, 15, by=0.02)
th_den <- b^a/gamma(a)*th_grid^(-a-1)*exp(-b/th_grid)

################################################
## Ex1: random walk M-H
################################################
M <- 10000 ### Monte Carlo sample size
th_sam <- rep(NA, M)

###### Proposal density: q(\theta^\prime \mid \theta)  #################
## Let q(\theta^\prime \mid \theta) = \Nor(0, v^2)  #####################
v <- 0.8

### starting value
th_cur <- 1.0

### iterate M times
### Evaluate on the logarithm to avoid any numerical problems ###
for(i_iter in 1:M)
{
    ## propose a value, xi using the proposal distribution
    xi <- th_cur + rnorm(1, 0, v)
    
    ## compute the acceptance prob. on the logarithm
    if(xi <= 0)
    {
        rho <- -Inf
    }else{
        rho <- -(a+1)*log(xi) - b/xi - (-(a+1)*log(th_cur) - b/th_cur)
    }
    
    if(log(runif(1)) < rho)  ## accept w/p rho
    {
        th_cur <- xi
    }##if(log(runif(1)) < rho)
    
    ### save the current value
    th_sam[i_iter] <- th_cur
} ## for(i_iter in 1:M)

pdf("MH-IG-ex1-acf1.pdf")
par(mar=c(4.5, 4.5, 2.1, 2.1))
acf(th_sam, cex.axis=2, cex.lab=2)
dev.off()


pdf("MH-IG-ex1-traceplot.pdf")
par(mar=c(4.5, 4.5, 2.1, 2.1))
plot(th_sam, type="l", ylab="theta", xlab="Iterations", cex.axis=2, cex.lab=2)
dev.off()


Burn <- 4000
thin <- 2
th_sam <- th_sam[seq(Burn+1, M, by=thin)]
mean(th_sam)
sd(th_sam)
length(th_sam)

pdf("MH-IG-ex1-hist.pdf")
par(mar=c(4.5, 4.5, 2.1, 2.1))
hist(th_sam, lwd=4, xlab="theta", cex.axis=2, cex.lab=2, probability=TRUE, ylim=c(0, 0.9), main="", nclass=20)
lines(th_grid, th_den, lty=2, lwd=4, col=2)
dev.off()



pdf("MH-IG-ex1-acf2.pdf")
par(mar=c(4.5, 4.5, 2.1, 2.1))
acf(th_sam, cex.axis=2, cex.lab=2)
dev.off()



################################################
## Ex2: random walk M-H -- with \eta=\log(\theta)
################################################
rm(list=ls(all=TRUE))
set.seed(454)

###### Target density: \pi(\theta)  #################
## Let \pi(\theta) = \IG(a, b) with mean b/(a-1)  #####################
a <- 3
b <- 3

th_grid <- seq(0.01, 15, by=0.02)
th_den <- b^a/gamma(a)*th_grid^(-a-1)*exp(-b/th_grid)

M <- 10000 ### Monte Carlo sample sizet
eta_sam <- rep(NA, M)

###### Proposal density: q(\theta^\prime \mid \theta)  #################
## Let q(\theta^\prime \mid \theta) = \Nor(0, v^2)  #####################
v <- 0.5

### starting value
eta_cur <- log(1.0)
e_eta_cur <- exp(eta_cur)

### iterate M times
for(i_iter in 1:M)
{
    ## propose a value, xi using the proposal distribution
    xi <- eta_cur + rnorm(1, 0, v)
    e_xi <- exp(xi)
    
    ## compute the acceptance prob.
    rho <- -a*xi - b/e_xi - (-a*eta_cur - b/e_eta_cur)
    
    if(log(runif(1)) < rho)  ## accept w/p rho
    {
        eta_cur <- xi
        e_eta_cur <- e_xi
    }##if(log(runif(1)) < rho)
    
    ### save the current value
    eta_sam[i_iter] <- eta_cur
}##for(i_iter in 1:M)

pdf("MH-IG-ex2-traceplot.pdf")
par(mar=c(4.5, 4.5, 2.1, 2.1))
plot(exp(eta_sam), type="l", ylab="theta", xlab="Iterations", cex.axis=2, cex.lab=2)
dev.off()


Burn <- 4000
thin <- 2
eta_sam <- eta_sam[seq(Burn+1, M, by=thin)]

mean(exp(eta_sam))
sd(exp(eta_sam))
library(coda)
effectiveSize(exp(eta_sam))


pdf("MH-IG-ex2-hist.pdf")
par(mar=c(4.5, 4.5, 2.1, 2.1))
hist(exp(eta_sam), lwd=4, xlab="theta", cex.axis=2, cex.lab=2, probability=TRUE, ylim=c(0, 0.9), main="", nclass=20)
lines(th_grid, th_den, lty=2, lwd=4, col=2)
dev.off()


################################################
## Ex2-1: random walk M-H -- with \eta=\log(\theta)
## with a different starting point
################################################
rm(list=ls(all=TRUE))
set.seed(4554)

###### Target density: \pi(\theta)  #################
## Let \pi(\theta) = \IG(a, b) with mean b/(a-1)  #####################
a <- 3
b <- 3

th_grid <- seq(0.01, 15, by=0.02)
th_den <- b^a/gamma(a)*th_grid^(-a-1)*exp(-b/th_grid)

M <- 10000 ### Monte Carlo sample sizet
eta_sam <- rep(NA, M)

###### Proposal density: q(\theta^\prime \mid \theta)  #################
## Let q(\theta^\prime \mid \theta) = \Nor(0, v^2)  #####################
v <- 0.5

### starting value
eta_cur <- log(10.0)
e_eta_cur <- exp(eta_cur)

### iterate M times
for(i_iter in 1:M)
{
    ## propose a value, xi using the proposal distribution
    xi <- eta_cur + rnorm(1, 0, v)
    e_xi <- exp(xi)
    
    ## compute the acceptance prob.
    rho <- -a*xi - b/e_xi - (-a*eta_cur - b/e_eta_cur)
    
    if(log(runif(1)) < rho)  ## accept w/p rho
    {
        eta_cur <- xi
        e_eta_cur <- e_xi
    }##if(log(runif(1)) < rho)  ## accept w/p rho
    
    ### save the current value
    eta_sam[i_iter] <- eta_cur
}##for(i_iter in 1:M)

pdf("MH-IG-ex2-1-traceplot.pdf")
par(mar=c(4.5, 4.5, 2.1, 2.1))
plot(exp(eta_sam), type="l", ylab="theta", xlab="Iterations", cex.axis=2, cex.lab=2)
dev.off()

Burn <- 4000
thin <- 2
eta_sam <- eta_sam[seq(Burn+1, M, by=thin)]

mean(exp(eta_sam))
sd(exp(eta_sam))

library(coda)
effectiveSize(exp(eta_sam))

pdf("MH-IG-ex2-1-hist.pdf")
par(mar=c(4.5, 4.5, 2.1, 2.1))
hist(exp(eta_sam), lwd=4, xlab="theta", cex.axis=2, cex.lab=2, probability=TRUE, ylim=c(0, 0.9), main="", nclass=100)
lines(th_grid, th_den, lty=2, lwd=4, col=2)
dev.off()




