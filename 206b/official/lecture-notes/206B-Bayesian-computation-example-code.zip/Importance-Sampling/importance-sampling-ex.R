rm(list=ls(all=TRUE))  ## clean up the workspace
set.seed(8147)  ## set the random seed

#############################################################
N <- 10
sig2 <- 9
x <- rnorm(N, 0, sqrt(sig2))
## generate my data from N(\theta=0, \sig2)
## Assume the true value of \theta is 0 but unknown to us
## We use N(\mu, \tau2) as the prior for \theta
## \sig2, \mu and \tau2 are fixed
#############################################################


###  Suppose we set \mu=0 and \sig2=1 => \theta \sim N(0, 1)
mu <- 0
tau2 <- 2

post_mean_0 <- 1/(N/sig2 + 1/tau2)*(mean(x)*N/sig2 + mu/tau2)
post_mean_0

post_var <- 1/(N/sig2 + 1/tau2)

### repeat x n times in rows ===> produce an n*dim(x) matrix
rep.row<-function(x,n){
    matrix(rep(x,each=n),nrow=n)
}

### repeat x n times in columns ===> produce an dim(x)*n matrix
rep.col<-function(x,n){
    matrix(rep(x,each=n), ncol=n, byrow=TRUE)
}


### CASE 1  #########################################
### Consider h(\theta) = N(0, 2^2),
#######################################################
n_sam <- 3000

x_tmp <- rep.row(x, n_sam)

th_sam <- rnorm(n_sam, 0, 2)
th_tmp <- rep.col(th_sam, N)

imp_v <- apply(dnorm(x_tmp, th_tmp, sqrt(sig2), log=TRUE), 1, sum)
imp_v <- exp(imp_v + dnorm(th_sam, mu, sqrt(tau2), log=TRUE) - dnorm(th_sam, 0, 2, log=TRUE))

post_mean_1 <- sum(th_sam*imp_v)/sum(imp_v)
post_mean_1


summary(imp_v)

### CASE 2  #########################################
### Consider h(\theta) = N(6, 2^2),
#######################################################
n_sam <- 3000

th_sam <- rnorm(n_sam, 6, 2)
th_tmp <- rep.col(th_sam, N)

imp_v <- apply(dnorm(x_tmp, th_tmp, sqrt(sig2), log=TRUE), 1, sum)
imp_v <- exp(imp_v + dnorm(th_sam, mu, sqrt(tau2), log=TRUE) - dnorm(th_sam, 6, 2, log=TRUE))

post_mean_2 <- sum(th_sam*imp_v)/sum(imp_v)
post_mean_2

summary(imp_v)

c(post_mean_0, post_mean_1, post_mean_2)

#######################################################
## Repeat  -- may not want to run since it takes long
#######################################################
set.seed(1864)
n_rep <- 5000
post_mean_1 <- post_mean_2 <- rep(0, n_rep)

for(i_rep in 1:n_rep)
{
    if((i_rep%%1000)==0)
    {
        print(paste("i.rep=", i_rep))
        print(date())
    }

    th_sam <- rnorm(n_sam, 0, 2)
    th_tmp <- rep.col(th_sam, N)
    
    imp_v <- apply(dnorm(x_tmp, th_tmp, sqrt(sig2), log=TRUE), 1, sum)
    imp_v <- exp(imp_v + dnorm(th_sam, mu, sqrt(tau2), log=TRUE) - dnorm(th_sam, 0, 2, log=TRUE))
    
    post_mean_1[i_rep] <- sum(th_sam*imp_v)/sum(imp_v)
    
    
    th_sam <- rnorm(n_sam, 6, 2)
    th_tmp <- rep.col(th_sam, N)
    
    imp_v <- apply(dnorm(x_tmp, th_tmp, sqrt(sig2), log=TRUE), 1, sum)
    imp_v <- exp(imp_v + dnorm(th_sam, mu, sqrt(tau2), log=TRUE) - dnorm(th_sam, 6, 2, log=TRUE))
    
    post_mean_2[i_rep] <- sum(th_sam*imp_v)/sum(imp_v)
} ## for(i_rep in 1:n_rep)


pdf("imp-sam-1.pdf")
par(mar=c(4.5, 4.5, 2.1, 2.1))
hist(post_mean_1, col="grey", xlab="theta_hat", main="", cex.axis=2, cex.lab=2, lwd=4)
abline(v=post_mean_0, col=2, lwd=3, lty=2)
dev.off()


pdf("imp-sam-2.pdf")
par(mar=c(4.5, 4.5, 2.1, 2.1))
hist(post_mean_2, col="grey", xlab="theta_hat", main="", cex.axis=2, cex.lab=2, lwd=4)
abline(v=post_mean_0, col=2, lwd=3, lty=2)
dev.off()


th_grid <- seq(-6, 12, by=0.1)

post_d <- dnorm(th_grid, post_mean_0, sqrt(post_var))
h1_d <- dnorm(th_grid, 0, 2)
h2_d <- dnorm(th_grid, 6, 2)


pdf("comp-den.pdf")
par(mar=c(4.5, 4.5, 2.1, 2.1))
plot(th_grid, post_d, type="l", xlab="theta", ylab="density", main="", cex.axis=2, cex.lab=2, lwd=4)
lines(th_grid, h1_d, col=2, lty=2, lwd=3)
lines(th_grid, h2_d, col=4, lty=4, lwd=3)
dev.off()








