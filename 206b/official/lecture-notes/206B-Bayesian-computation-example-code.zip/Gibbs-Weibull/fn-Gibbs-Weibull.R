
## update alpha given eta and data
fn.update.alpha <- function(alpha_cur, v_1, eta, Sum_log_x, X, N, aa)
{
    ## propose a value, xi using the proposal distribution
    a_pro <- exp(log(alpha_cur) + rnorm(1, 0, v_1))
    
    ## compute the acceptance prob.
    ### evaluate with the proposed value
    rho_pro <- N*log(a_pro) + (a_pro-1)*Sum_log_x - eta*sum(X^a_pro) # the likelihood
    rho_pro <- rho_pro - aa*a_pro + log(a_pro) ### prior + Jacobian
    
    ### evaluate with the current value
    rho_cur <- N*log(alpha_cur) + (alpha_cur-1)*Sum_log_x - eta*sum(X^alpha_cur) #the likelihood
    rho_cur <- rho_cur - aa*alpha_cur + log(alpha_cur) ### prior + Jacobian
    
    if(log(runif(1)) < (rho_pro - rho_cur))  ## accept w/p rho
    {
        alpha_cur <- a_pro
    }
    
    return(alpha_cur)
}



## update eta given alpha and data
fn.update.eta <- function(alpha, X, N, beta, xi)
{
    eta_new <- rgamma(1, N+beta, sum(X^alpha) + xi)  ## E(eta \mid alpha, x) = (n+beta)/(xi + \sum x^alpha)

    return(eta_new)
}


## run MCMC
fn.run.MCMC <- function(hyper, n_burn, n_sam, n_thin, dat_x, dat_n, a_cur, e_cur)
{
    ## update th using MH-RW
    ###### Proposal density: q(\theta^\prime \mid \theta)  #################
    ## Let q(\theta^\prime \mid \theta) = \Nor(0, v^2)  #####################
    v <- 0.1  ### to propose a new value of alpha
    
    ### factor that I need all the time to run MC
    ##%%%  I save this and use instead of computing every time.
    sum_log_x <- sum(log(dat_x))
    
    ### iterate for inf
    tot_iter <- n_burn + n_sam
    th_sam <- NULL
    th_sam$alpha <- rep(NA, tot_iter)
    th_sam$eta <- rep(NA, tot_iter)
    
    for(i_iter in 1:tot_iter)
    {
        #print(i_iter)
        ## update alpha given eta and data
        a_cur <- fn.update.alpha(a_cur, v[1], e_cur, sum_log_x, dat_x, dat_n, hyper$a)
        
        ## update eta given alpha and data
        e_cur <- fn.update.eta(a_cur, dat_x, dat_n, hyper$beta, hyper$xi)
        
        ### save the current value
        th_sam$alpha[i_iter] <- a_cur
        th_sam$eta[i_iter] <- e_cur
    }
    
    pdf("Gibbs-W-trace1.pdf")
    par(mar=c(4.5, 4.5, 2.1, 2.1))
    plot(th_sam$alpha, type="l", ylab="alpha", xlab="Iterations", cex.axis=2, cex.lab=2)
    abline(h=tr_alpha, col=2, lwd=2)
    dev.off()
    
    pdf("Gibbs-W-trace2.pdf")
    par(mar=c(4.5, 4.5, 2.1, 2.1))
    plot(th_sam$eta, type="l", ylab="eta", xlab="Iterations", cex.axis=2, cex.lab=2)
    abline(h=tr_eta, col=2, lwd=2)
    dev.off()

    a_sam <- th_sam$alpha[seq(n_burn+1, tot_iter, by=n_thin)]
    e_sam <- th_sam$eta[seq(n_burn+1, tot_iter, by=n_thin)]
    
    return(list(alpha=a_sam, eta=e_sam))
}

