rm(list=ls(all=TRUE))  ## clean up the workspace
set.seed(8147)  ## set the random seed

#############################################################
a <- 2
b <- 5
#############################################################

m <- (a -1)/(a+b-2)
v <- (a-1)*(b-1)/(a+b-2)^3


th_grid_1 <- seq(0.001, 0.99, by=0.01)
th_grid_2 <- seq(-0.5, 1.5, by=0.01)


n_den <- dnorm(th_grid_2, m, sqrt(v))
b_den <- dbeta(th_grid_1, a, b)

pdf("Laplace-1.pdf")
par(mar=c(4.5, 4.5, 2.1, 2.1))
plot(th_grid_2, n_den, type="l", col=2, lty=2, ylim=c(0, max(c(n_den, b_den))), ylab="density", xlab="theta", cex.axis=2, cex.lab=2, lwd=4)
lines(th_grid_1, b_den, col=1, lwd=4)
dev.off()



#############################################################
a <- 4
b <- 10
#############################################################

m <- (a -1)/(a+b-2)
v <- (a-1)*(b-1)/(a+b-2)^3


th_grid_1 <- seq(0.001, 0.99, by=0.01)
th_grid_2 <- seq(-0.5, 1.5, by=0.01)


n_den <- dnorm(th_grid_2, m, sqrt(v))
b_den <- dbeta(th_grid_1, a, b)

pdf("Laplace-2.pdf")
par(mar=c(4.5, 4.5, 2.1, 2.1))
plot(th_grid_2, n_den, type="l", col=2, lty=2, ylim=c(0, max(c(n_den, b_den))), ylab="density", xlab="theta", cex.axis=2, cex.lab=2, lwd=4)
lines(th_grid_1, b_den, col=1, lwd=4)
dev.off()


