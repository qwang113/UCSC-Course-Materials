rm(list=ls(all=TRUE))

## Likelihood: x \mid \th \sim \Nor(\th, 1)
## Prior: \th \sim N(0, 2.19) or Cauchy(0, 1)


####  some functions that I need later
### compute the marginal distribution to compute the posterior under Cauchy
integrand1 <- function(th, x, sig2, mu) {
    exp(-(th-mu)^2/2/sig2)*prod(1/(1.0+(x-th)^2))
}



### repeat x n times in rows ===> produce an n*dim(x) matrix
rep.row<-function(x,n){
    matrix(rep(x,each=n),nrow=n)
}

### repeat x n times in columns ===> produce an dim(x)*n matrix
rep.col<-function(x,n){
    matrix(rep(x,each=n), ncol=n, byrow=TRUE)
}

###########################################################################
set.seed(45545)

### grid of theta to evaluate prior/posterior densities
th_grid <- seq(-2, 2, by=0.01)
n_grid <- length(th_grid)

## prior: th ~ N(mu, sig2) fixed hyperparameters
mu <- 0 ## prior mean for normal prior
sig2 <- 25  ## prior variance for normal prior

##### simulate data from Cauchy(0, 1)
n <- 15 ## sample size
x <- rt(n, 1) ## caucy with th=0

## normalizing constant
tmp1 <- integrate(integrand1, x, sig2, mu, lower = -Inf, upper = Inf)
tmp <- 1.0/(1 + (rep.row(x, n_grid) - rep.col(th_grid, n))^2)

### Exact posterior density evaluated at the theta_grid (but the normalizing constant is numerically approximated)
post_den <- apply(tmp, 1, prod)*exp(-(th_grid-mu)^2/2/sig2)/tmp1$value

# Obtain the maximum and the Hessian at the maximum  -- it minimizes so retrun -r
fn_f <- function(th) {
    r <- -(th-mu)^2/2/sig2 - sum((1.0+(x-th)^2))
    return(-r)
}

##########################################################
###  Laplace approximation N(mode, hessian evaluated at the mode)
lap <- optim(0, fn_f, hessian = TRUE, method="BFGS")
laplace_app <- dnorm(th_grid, lap$par, sqrt(1/lap$hessian))


pdf("laplace-C.pdf")
par(mar=c(4.5, 4.5, 2.1, 2.1))
plot(th_grid, post_den, type="l", ylim=c(0, 2.2), ylab="Density", cex.axis=2, cex.lab=2, xla="theta", lwd=4)
lines(th_grid, laplace_app, col=2, lty=2, lwd=4)

legend("topright", legend=c("Exact", "Laplace Approx"), col=c(1, 2), cex=1.5, lwd=2, bty="n", lty=c(1, 2))
abline(h=0)

dev.off()

