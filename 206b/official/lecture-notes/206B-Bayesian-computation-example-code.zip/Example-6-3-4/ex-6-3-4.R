rm(list=ls(all=TRUE))  ## clean up the workspace
set.seed(8147)  ## set the random seed

#############################################################
### specify values needed -- alpha, beta (which are functions of data)
n <- 54
alpha <- 3.4
beta <- 5.2
#############################################################
N <- 5000 ## sample size


#%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
### Method 1
### Directly sample from the marginal distribution of \theta
### Beta-binomial(n, alpha, beta)
#%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
library(rmutil)
theta_sam1 <- rbetabinom(N, n, alpha/(alpha + beta), (alpha + beta))



#%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
### Method 2
### Using the hierarchical structure
### simulate \lambda from Beta(alpha, beta)
### simulate \theta from binom(n, \lambda)
#%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
lam_sam2 <- rbeta(N, alpha, beta)
theta_sam2 <- rbinom(N, n, lam_sam2)


#%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
### Method 3
### Using Gibbs sampling
### simulate \lambda from Beta(alpha + theta, beta + n - theta)
### simulate \theta from binom(n, \lambda)
#%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
lam_sam3 <- rep(NA, N)
theta_sam3 <- rep(NA, N)


### specify initial values
cur_sam <- NULL
cur_sam$lam <- 1.0
cur_sam$theta <- NA

N_burn <- 1000
## burn-in
for(i_iter in 1:N_burn)
{
    ### sample \theta from \pi(\theta \mid \lambda, x)
    cur_sam$theta <- rbinom(1, n, cur_sam$lam)
    
    ### sample \lambda from \pi(\lambda \mid \theta, x)
    cur_sam$lam <- rbeta(1, alpha + cur_sam$theta, beta + n - cur_sam$theta)
}## for(i_iter in 1:N_burn)


for(i_iter in 1:N)
{
    ### sample \theta from \pi(\theta \mid \lambda, x)
    cur_sam$theta <- rbinom(1, n, cur_sam$lam)
    
    ### sample \lambda from \pi(\lambda \mid \theta, x)
    cur_sam$lam <- rbeta(1, alpha + cur_sam$theta, beta + n - cur_sam$theta)
    
    ## save the current value
    theta_sam3[i_iter] <- cur_sam$theta
    lam_sam3[i_iter] <- cur_sam$lam
}## for(i_iter in 1:N)


theta_grid <- seq(0, n, by=1)
theta_den <- dbetabinom(theta_grid, n, alpha/(alpha + beta), (alpha + beta))


tmp_prob <- rep(0, n+1)
for(i in 0:n)
{
    tmp_prob[i+1] <- mean(theta_sam1==i)
}

pdf("sam-1.pdf")
par(mar=c(4.5, 4.5, 2.1, 2.1))
plot(theta_grid, tmp_prob, xlab="theta", main="", type="h", cex.axis=2, cex.lab=2, lwd=4)
points(theta_grid, theta_den, col=2, lwd=4)
dev.off()

tmp_prob <- rep(0, n+1)
for(i in 0:n)
{
    tmp_prob[i+1] <- mean(theta_sam2==i)
}

pdf("sam-2.pdf")
par(mar=c(4.5, 4.5, 2.1, 2.1))
plot(theta_grid, tmp_prob, xlab="theta", main="", type="h", cex.axis=2, cex.lab=2, lwd=4)
points(theta_grid, theta_den, col=2, lwd=4)
dev.off()

tmp_prob <- rep(0, n+1)
for(i in 0:n)
{
    tmp_prob[i+1] <- mean(theta_sam3==i)
}

pdf("sam-3.pdf")
par(mar=c(4.5, 4.5, 2.1, 2.1))
plot(theta_grid, tmp_prob, xlab="theta", main="", type="h", cex.axis=2, cex.lab=2, lwd=4)
points(theta_grid, theta_den, col=2, lwd=4)
dev.off()



pdf("sam-3-joint.pdf")
par(mar=c(4.5, 4.5, 2.1, 2.1))
plot(theta_sam3, lam_sam3, xlab="theta", ylab="lambda", main="", cex.axis=2, cex.lab=2, lwd=1)
dev.off()


pdf("sam-3-lam.pdf")
par(mar=c(4.5, 4.5, 2.1, 2.1))
hist(lam_sam3, xlab="lambda", main="", cex.axis=2, cex.lab=2, lwd=4)
dev.off()





