fn_check_mixing <- function(MCMCsam, n_sam, n_burnin, n_thin, model_no, dat)
{
    ## MCMCsam <- M1_MCMC_sam; n_sam <- N_sam; n_burnin <- N_burnin; n_thin <- N_thin; model_no <- 1; dat <- my_dat
    file_name <- paste("fig/M", model_no, "-mixing.pdf", sep="")

    pdf(file_name)
    par(mfrow=c(2,2))
    for(i_p in 1:dat$p)
    {
        plot(1:n_sam, MCMCsam$be[i_p,], type="l", main=paste("beta ", i_p, sep=""))
    }
    
    plot(1:n_sam, MCMCsam$sig2, type="l")
    dev.off()
    
    
    my_MCMC_sam <- NULL
    my_MCMC_sam$be <- MCMCsam$be[, seq((n_burnin+1), n_sam, by=n_thin)]
    my_MCMC_sam$sig2 <- MCMCsam$sig2[seq((n_burnin+1), n_sam, by=n_thin)]

    
    ## BEGINE: compute BIC
    n_sam1 <- length(my_MCMC_sam$sig2)  ## no of samples for inference
    
    ## point estimate
    be_hat <- apply(my_MCMC_sam$be, 1, mean)
    sig2_hat <- mean(my_MCMC_sam$sig2)
    
    BIC <- 0
    for(i_sam in 1:n_sam1)
    {
        BIC <- BIC + sum(dnorm(dat$y, (dat$x%*%my_MCMC_sam$be[,i_sam])[,1], sqrt(my_MCMC_sam$sig2[i_sam]), log=TRUE))
    }
    
    
   BIC <- -2*sum(dnorm(dat$y, (dat$x%*%be_hat)[,1], sqrt(sig2_hat), log=TRUE)) - 4*BIC/n_sam1
   ## END: compute BIC
    
    return(list(MCMC_sam = my_MCMC_sam, BIC=BIC))
}# fn_check_mixing



fn_post_pred <- function(MCMCsam, X_new)
{
    ## MCMCsam <- M3_MCMC_sam_1; X_new <- x_new
    
    n_new <- nrow(X_new)
    n_sam1 <- length(MCMCsam$sig2)  ## no of samples for inference
    
    y_pred <- array(NA, dim=c(n_new, n_sam1))
    for(i_sam in 1:n_sam1)
    {
        y_pred[,i_sam] <- rnorm(n_new, (X_new%*%MCMCsam$be[,i_sam])[,1], sqrt(MCMCsam$sig2[i_sam]))
    }
    
    
    return(y_pred)
}# fn_check_mixing





fn_MCMC_reg <- function(dat, hpara, n_sam)
{
    ## dat <- my_dat; hpara <- hyper; n_sam <- N_sam
    xtx <- t(dat$x)%*%dat$x
    xtx_inv <- solve(xtx)

    bhat <- solve(xtx)%*%t(dat$x)%*%dat$y
    s2 <- sum(((dat$y - dat$x%*%bhat))^2)

    print("OLS Estimates, beta and sig2")
    print(c(bhat, mean(s2)))
    
    xty <- t(dat$x)%*%dat$y

    Sig0_inv_b0 <- hpara$Sig0_inv%*%hpara$b0
    
    ## initialize MC
    cur_sam <- NULL
    cur_sam$be <- bhat
    cur_sam$sig2 <- s2/dat$n

    ## save samples
    MCMC_sam <- NULL
    MCMC_sam$be <- array(NA, dim=c(dat$p, n_sam))
    MCMC_sam$sig2 <- rep(NA, n_sam)
    
    for(i_iter in 1:n_sam)
    {
        ## update beta
        cur_sam$be <- fn_update_be(xtx, xty, Sig0_inv_b0, hpara$Sig0_inv, cur_sam$sig2)
 
        ## update sig2
        bxtxb <- t(cur_sam$be - bhat)%*%xtx%*%(cur_sam$be - bhat)
        cur_sam$sig2 <- fn_update_sig2(s2, n, hpara$b0, hpara$Sig0_inv, hpara$nu, hpara$s02, bxtxb)

        MCMC_sam$be[,i_iter] <- cur_sam$be
        MCMC_sam$sig2[i_iter] <- cur_sam$sig2

    }##     for(i_iter in 1:N_sam)

    return(MCMC_sam)
}#fn_MCMC_reg <- function(dat, hpara, N_sam)



fn_update_be <- function(xtx, xty, Sig0_inv_b0, Sig0_inv, sig2)
{
    ## Sig0_inv <- hpara$Sig0_inv; sig2 <- cur_sam$sig2
    Sigma <- solve(1/sig2*xtx + Sig0_inv)
    mu <- Sigma%*%(1/sig2*xty + Sig0_inv_b0)

    be <- mvrnorm(n = 1, mu, Sigma)
    return(be)
}## fn_update_be <- function(xtx_inv, Sig0_inv, xtx_bhat, b0, sig2)

fn_update_sig2 <- function(s2, n, b0, Sig0_inv, nu, s02, bxtxb)
{
   sig2 <- 1.0/rgamma(1, (n+nu)/2, (s02 + s2 + bxtxb)/2.0)
    
    return(sig2)
}## fn_update_be <- function(xtx_inv, Sig0_inv, xtx_bhat, b0, sig2)



