rm(list=ls(all=TRUE))
set.seed(454)
library(MASS)
source("fn-oxygen-uptake-ex3.R")

### data
x1 <- c(0,0,0,0,0,0,1,1,1,1,1,1)
x2 <- c(23,22,22,25,27,20,31,23,27,28,22,24)
y <- c(-0.87,-10.74,-3.27,-1.97,7.50,-7.25,17.05,4.96,10.40,11.05,0.26,2.51)
n <- length(x1)

## MCMC parameters
N_burnin <- 5000
N_sam <- 10000
N_thin <- 2



#%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
### model 1: y= b0 + b1 x1 + e
my_dat <- NULL
my_dat$x <- cbind(1, x1)
my_dat$y <- y
my_dat$n <- n
my_dat$p <- ncol(my_dat$x)

### set up fixed hyperparameters
hyper <- NULL
hyper$b0 <- c(mean(my_dat$y), rep(0, my_dat$p-1))
hyper$Sig0_inv <- solve(as.matrix(diag(10000, my_dat$p)))
hyper$nu <- 3
hyper$s02 <- 3


set.seed(454)
M1_MCMC_sam <- fn_MCMC_reg(my_dat, hyper, N_sam)

### checking mixing, burn-in and thining, and compute BIC
tmp <- fn_check_mixing(M1_MCMC_sam, N_sam, N_burnin, N_thin, 1, my_dat)
M1_MCMC_sam_1 <- tmp$MCMC_sam
M1_BIC <- tmp$BIC



apply(M1_MCMC_sam_1$be, 1, mean)
apply(M1_MCMC_sam_1$be, 1, sd)
apply(M1_MCMC_sam_1$be, 1, quantile, prob=c(0.025, 0.975))

mean(M1_MCMC_sam_1$sig2)
sd(M1_MCMC_sam_1$sig2)
quantile(M1_MCMC_sam_1$sig2, prob=c(0.025, 0.975))

M1_BIC


#%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
### model 2: y= b0 + b2 x2 + e
my_dat <- NULL
my_dat$x <- cbind(1, x2)
my_dat$y <- y
my_dat$n <- n
my_dat$p <- ncol(my_dat$x)

### set up fixed hyperparameters
hyper <- NULL
hyper$b0 <- c(mean(my_dat$y), rep(0, my_dat$p-1))
hyper$Sig0_inv <- solve(as.matrix(diag(10000, my_dat$p)))
hyper$nu <- 3
hyper$s02 <- 3


set.seed(454)
M1_MCMC_sam <- fn_MCMC_reg(my_dat, hyper, N_sam)

### checking mixing, burn-in and thining, and compute BIC
tmp <- fn_check_mixing(M1_MCMC_sam, N_sam, N_burnin, N_thin, 2, my_dat)
M2_MCMC_sam_1 <- tmp$MCMC_sam
M2_BIC <- tmp$BIC



apply(M2_MCMC_sam_1$be, 1, mean)
apply(M2_MCMC_sam_1$be, 1, sd)
apply(M2_MCMC_sam_1$be, 1, quantile, prob=c(0.025, 0.975))

mean(M2_MCMC_sam_1$sig2)
sd(M2_MCMC_sam_1$sig2)
quantile(M2_MCMC_sam_1$sig2, prob=c(0.025, 0.975))

M2_BIC



#%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
### model 3: y= b0 + b1 x1 + b2 x2 + e
my_dat <- NULL
my_dat$x <- cbind(1, x1, x2)
my_dat$y <- y
my_dat$n <- n
my_dat$p <- ncol(my_dat$x)

### set up fixed hyperparameters
hyper <- NULL
hyper$b0 <- c(mean(my_dat$y), rep(0, my_dat$p-1))
hyper$Sig0_inv <- solve(as.matrix(diag(10000, my_dat$p)))
hyper$nu <- 3
hyper$s02 <- 3


set.seed(454)
M1_MCMC_sam <- fn_MCMC_reg(my_dat, hyper, N_sam)

### checking mixing, burn-in and thining, and compute BIC
tmp <- fn_check_mixing(M1_MCMC_sam, N_sam, N_burnin, N_thin, 3, my_dat)
M3_MCMC_sam_1 <- tmp$MCMC_sam
M3_BIC <- tmp$BIC



apply(M3_MCMC_sam_1$be, 1, mean)
apply(M3_MCMC_sam_1$be, 1, sd)
apply(M3_MCMC_sam_1$be, 1, quantile, prob=c(0.025, 0.975))

mean(M3_MCMC_sam_1$sig2)
sd(M3_MCMC_sam_1$sig2)
quantile(M3_MCMC_sam_1$sig2, prob=c(0.025, 0.975))

M3_BIC


## predictive exercise
set.seed(87789)
x_new0 <- cbind(1, 0, c(seq(20, 30, by=2)))
x_new1 <- cbind(1, 1, c(seq(20, 30, by=2)))

x_new <- rbind(x_new0, x_new1)
pred_dist <- fn_post_pred(M3_MCMC_sam_1, x_new)



library(ggplot2)

pred_dist0 <- cbind(x_new[1,3], pred_dist[1,])
for(i in 2:5)
{
    pred_dist0 <- rbind(pred_dist0, cbind(x_new[i,3], pred_dist[i,]))
}

pred_dist0 <- as.data.frame(pred_dist0)
colnames(pred_dist0) <- c("age", "y")
pred_dist0$age <- as.factor(pred_dist0$age)

p <- ggplot(pred_dist0, aes(x=age, y=y)) + geom_violin(trim=FALSE, fill='#A4A4A4', color="darkred") + ylim(-30, 32)
pdf("M3-pred0.pdf")
p
dev.off()

pred_dist1 <- cbind(x_new[7,3], pred_dist[7,])
for(i in 2:5)
{
    pred_dist1 <- rbind(pred_dist1, cbind(x_new[7+i,3], pred_dist[7+i,]))
}

pred_dist1 <- as.data.frame(pred_dist1)
colnames(pred_dist1) <- c("age", "y")
pred_dist1$age <- as.factor(pred_dist1$age)

p <- ggplot(pred_dist1, aes(x=age, y=y)) + geom_violin(trim=FALSE, fill='#A4A4A4', color="darkred") + ylim(-30, 32)
pdf("M3-pred1.pdf")
p
dev.off()





# Basic violin plot
p <- ggplot(ToothGrowth, aes(x=dose, y=len)) +
  geom_violin()
p


#%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
### model 4: y= b0 + b1 x1 + b2 x2 + b3*x1*x2 + e
my_dat <- NULL
my_dat$x <- cbind(1, x1, x2, x1*x2)
my_dat$y <- y
my_dat$n <- n
my_dat$p <- ncol(my_dat$x)

### set up fixed hyperparameters
hyper <- NULL
hyper$b0 <- c(mean(my_dat$y), rep(0, my_dat$p-1))
hyper$Sig0_inv <- solve(as.matrix(diag(10000, my_dat$p)))
hyper$nu <- 3
hyper$s02 <- 3


set.seed(454)
M1_MCMC_sam <- fn_MCMC_reg(my_dat, hyper, N_sam)

### checking mixing, burn-in and thining, and compute BIC
tmp <- fn_check_mixing(M1_MCMC_sam, N_sam, N_burnin, N_thin, 4, my_dat)
M4_MCMC_sam_1 <- tmp$MCMC_sam
M4_BIC <- tmp$BIC



apply(M4_MCMC_sam_1$be, 1, mean)
apply(M4_MCMC_sam_1$be, 1, sd)
apply(M4_MCMC_sam_1$be, 1, quantile, prob=c(0.025, 0.975))

mean(M4_MCMC_sam_1$sig2)
sd(M4_MCMC_sam_1$sig2)
quantile(M4_MCMC_sam_1$sig2, prob=c(0.025, 0.975))

M4_BIC



