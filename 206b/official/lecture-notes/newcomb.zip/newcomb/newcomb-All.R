rm(list=ls(all=TRUE))
source("fn-newcomb.R")

## install package that include the datasets in BDA
### install.packages("BayesDA")
library(BayesDA)

### load dataset "light" into the workspace
data(light)
comment(light)

#### explore data
pdf("newcomb-data.pdf")
par(mar=c(4.5, 4.5, 2.1, 2.1))
hist(light, breaks=40, lwd=4, cex.axis=2, cex.lab=2)
abline(v=33.0, col="red", lwd=4)
abline(v=mean(light), col=4, lwd=4)
abline(v=mean(light[light>0]), col=4, lwd=4)

dev.off()



## assume x \iid N(\theta, \sig2), where \theta and \sig2 are unknown
my_dat <- NULL
my_dat$x <- light
my_dat$xbar <- mean(my_dat$x)
my_dat$s2 <- sum((my_dat$x - my_dat$xbar)^2)
my_dat$n <- length(my_dat$x)

### specify hyperparameter values
hyper <- NULL

## \theta ~ N(\mu, \tau2)
hyper$mu <- 33
hyper$tau2 <- 100

## \sig2 ~ IG(a0, b0)
hyper$a0 <- 0.1
hyper$b0 <- 0.1


### initialize theta and sig2
cur_sam <- NULL
cur_sam$theta <- my_dat$x_bar
cur_sam$sig2 <- var(my_dat$x)


## specify MCMC parameters
N_iter <- 20000
N_burnin <- 5000
N_thin <- 2

MCMC_sam <- NULL
MCMC_sam$theta <- rep(NA, N_iter)
MCMC_sam$sig2 <- rep(NA, N_iter)


for(i_iter in 1:N_iter)
{
    if((i_iter%%1000)==0)
    {
        print(paste("i_iter=", i_iter))
    }
    
    ## udpate theta
    cur_sam$theta <- fn_update_theta(my_dat$n, my_dat$xbar, cur_sam$sig2, hyper$mu, hyper$tau2)

    ## update sig2
    cur_sam$sig2 <- fn_update_sig2(hyper$a0, hyper$b0, my_dat$n, my_dat$xbar, my_dat$s2, cur_sam$theta)

    ## save current (\theta, \sig2
    MCMC_sam$theta[i_iter] <- cur_sam$theta
    MCMC_sam$sig2[i_iter] <- cur_sam$sig2
}###  for(i_iter in 1:N_iter)



pdf("All/theta-traceplot.pdf")
par(mar=c(4.5, 4.5, 2.1, 2.1))
plot(MCMC_sam$theta, type="l", ylab="theta", xlab="Iterations", cex.axis=2, cex.lab=2)
dev.off()

pdf("All/sig2-traceplot.pdf")
par(mar=c(4.5, 4.5, 2.1, 2.1))
plot(MCMC_sam$sig2, type="l", ylab="sig2", xlab="Iterations", cex.axis=2, cex.lab=2)
dev.off()


### samples that will be used for inference
my_th <- MCMC_sam$theta[-(1:N_burnin)]
my_th <- my_th[seq(1, (N_iter - N_burnin), by=N_thin)]

my_sig2 <- MCMC_sam$sig2[-(1:N_burnin)]
my_sig2 <- my_sig2[seq(1, (N_iter - N_burnin), by=N_thin)]


### summaries of the margianl posterior of theta
post_m_th <- mean(my_th)
post_sd_th <- sd(my_th)
ci_th <- quantile(my_th, prob=c(0.025, 0.975))
post_m_th
post_sd_th
ci_th

### summaries of the margianl posterior of sig2
post_m_sig2 <- mean(my_sig2)
post_sd_sig2 <- sd(my_sig2)
ci_sig2 <- quantile(my_sig2, prob=c(0.025, 0.975))
post_m_sig2
post_sd_sig2
ci_sig2

th_grid <- seq(20, 35, by=0.1)
th_prior <- dnorm(th_grid, hyper$mu, sqrt(hyper$tau2))
pdf("All/post-th.pdf")
par(mar=c(4.5, 4.5, 2.1, 2.1))
hist(my_th, lwd=4, xlab="theta", cex.axis=2, cex.lab=2, prob="TRUE")
abline(v=c(ci_th, post_m_th), col=4, lwd=2, lty=2)
lines(th_grid, th_prior, col=2, lwd=2, lty=2)
dev.off()


sig2_grid <- seq(69, 235, by=0.1)
sig2_prior <- exp(hyper$a0*log(hyper$b0) - gamma(hyper$a0) - (hyper$a0 + 1)*log(sig2_grid) - hyper$b0/sig2_grid)
pdf("All/post-sig2.pdf")
par(mar=c(4.5, 4.5, 2.1, 2.1))
hist(my_sig2, lwd=4, xlab="sig2", cex.axis=2, cex.lab=2, prob="TRUE")
abline(v=c(ci_sig2, post_m_sig2), col=4, lwd=2, lty=2)
lines(sig2_grid, sig2_prior, col=2, lwd=2, lty=2)
dev.off()

###%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
#%%% Make a plot of the joint posterior of alpha and eta
library(MASS)
z <- kde2d(my_th, my_sig2, n=50)

pdf("All/th-sig2-joint.pdf")
par(mar=c(4.5, 4.5, 2.1, 2.1))
plot(cbind(my_th, my_sig2), xlab="theta", ylab="sig2", pch=19, cex=0.4, cex.axis=2, cex.lab=2)
contour(z, drawlabels=FALSE, nlevels=10, add=TRUE, lwd=1.5, col=4)
points(post_m_th, post_m_sig2, lwd=6, pch=4, col=2)
dev.off()

###%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
#%%%## preditive distribution
y_pred <- rnorm(length(my_th), my_th, sqrt(my_sig2))
mean(y_pred)
sd(y_pred)
quantile(y_pred, prob=c(0.025, 0.975))

y_max <- max(c(my_dat$x, y_pred))
y_min <- min(c(my_dat$x, y_pred))

pdf("All/pred-y.pdf")
par(mar=c(4.5, 4.5, 2.1, 2.1))
hist(y_pred, lwd=4, xlab="speed of light", cex.axis=2, cex.lab=2, prob="TRUE", ylim=c(0, 0.1), breaks=40, xlim=c(y_min, y_max))
abline(v=c(mean(y_pred), quantile(y_pred, prob=c(0.025, 0.975))), col=4, lwd=2, lty=2)
hist(my_dat$x, lwd=4, cex.axis=2, cex.lab=2, prob="TRUE", add=T, col=rgb(1,0,0,0.5), breaks=40)
dev.off()























