
## update theta
fn_update_theta <- function(n, xbar, sig2, mu, tau2)
{
    my_var <- 1.0/(n/sig2 + 1.0/tau2)
    my_mean <- my_var*(n*xbar/sig2 + mu/tau2)

    return(rnorm(1, my_mean, sqrt(my_var)))
}


## update sig2
### a0 <- hyper$a0; b0 <- hyper$b0; n <- my_dat$n; xbar <- my_dat$xbar; s2 <- my_dat$s2; theta <- cur_sam$theta
fn_update_sig2 <- function(a0, b0, n, xbar, s2, theta)
{
    my_a <- (n/2.0 + a0)
    my_b <- (s2 + n*(theta - xbar)^2.0 + 2.0*b0)/2.0

    return(1.0/rgamma(1, my_a, my_b))
}
