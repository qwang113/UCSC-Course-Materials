fn.do.MCMC <- function(JJ, obs, N_sam, hyper, cur_sam)
{
    ### save MCMC draws
    save_sam <- NULL
    save_sam$mu <- array(NA, dim=c(hyper$k, N_sam))
    save_sam$p <- array(NA, dim=c(hyper$k, N_sam))
    
    save_sam$mu_obs <- array(NA, dim=c(JJ, N_sam))
    save_sam$lam <- array(NA, dim=c(JJ, N_sam))
    
    save_sam$sig2 <- rep(NA, N_sam)
    
    
    for(i_iter in 1:N_sam)
    {
        if((i_iter%%1000)==0)
        {
            print(date())
            print(paste("i_iter=", i_iter))
        }
        
        ### update mu
        cur_sam$mu <- fn.update.mu(obs, hyper$k, hyper$mu_bar, hyper$tau2, cur_sam$sig2, cur_sam$lam)
        cur_sam$mu_obs <- cur_sam$mu[cur_sam$lam]
        
        ## update lambda
        cur_sam$lam <- fn.update.lam(obs, hyper$k, JJ, cur_sam$p, cur_sam$mu, cur_sam$sig2)
        cur_sam$mu_obs <- cur_sam$mu[cur_sam$lam]
        
        ### update p
        cur_sam$p <- fn.update.p_k(obs, hyper$k, hyper$alpha, cur_sam$lam)
        
        ### udpate sig2
        cur_sam$sig2 <- fn.update.sig2(hyper$a, hyper$b, obs, cur_sam$mu_obs, JJ)
        
        ### save current draws
        save_sam$mu[,i_iter] <- cur_sam$mu
        save_sam$p[,i_iter] <- cur_sam$p
        
        save_sam$mu_obs[,i_iter] <- cur_sam$mu_obs
        save_sam$lam[,i_iter] <- cur_sam$lam
        
        save_sam$sig2[i_iter] <- cur_sam$sig2
    }
    
    return(save_sam)
}

### update p_k given all the other parameters and data
fn.update.p_k <- function(obs, K, alpha_vec, lam)
{
    ## sizes of components (how many obs in each component)
    size_k <- table(c(lam, (1:K))) - 1
    
    #### Recall math stat
    #### y_l \indep Ga(a_l, 1)
    #### (y_1/\sum y, ..., y_k/\sum y) ~ Dir(a_1, ..., a_k)
    p_k <- rgamma(K, size_k + alpha_vec, 1)
    p_k <- p_k/sum(p_k)

    return(p_k)
}



### update sig2 given all the other parameters and data
fn.update.sig2 <- function(aa, bb, obs, mu_obs, JJ)
{
    ### enjoy the conditional conjugacy thanks to lambda! :-)
    a_tmp <- aa + JJ/2.0
    b_tmp <- bb + sum((obs-mu_obs)^2)/2.0
    
    sig2 <- 1.0/rgamma(1, a_tmp, b_tmp)
    
    return(sig2)
}


### update mu given all the other parameters and data
fn.update.mu <- function(obs, K, mu_bar, tau2, sig2, lam)
{
    ### new mu
    mu <- rep(NA, K)
    
    ## sizes of components (how many obs in each component)
    size_k <- table(c(lam, (1:K))) - 1
    
    ## iterate through components
    for(k in 1:K)
    {
        ### enjoy the conditional conjugacy thanks to lambda! :-)
        v_k <- 1/(1/tau2 + size_k[k]/sig2)
        m_k <- v_k*(mu_bar/tau2 + sum(obs[lam==k])/sig2)
        mu[k] <- rnorm(1, m_k, sqrt(v_k))
    }
    
    return(mu)
}

### update lambda given all the other parameters and data
fn.update.lam <- function(obs, K, JJ, p_k, mu_vec, sig2)
{
    log_p_k <- log(p_k)
    grid_K <- (1:K)
    
    ## save new lam
    lam <- rep(NA, JJ)
    
    ## go over obs
    ### now we have to pay the price! we update the auxiliary variable.
    for(j in 1:JJ)
    {
        ### prob on log
        prob <- log_p_k -(obs[j] - mu_vec)^2/2/sig2
        
        ### sample one component
        lam[j] <- sample(grid_K, 1, TRUE, exp(prob))
    }
    
    return(lam)
}




### repeat x n times in rows ===> produce an n*dim(x) matrix
rep.row<-function(x,n){
    matrix(rep(x,each=n),nrow=n)
}

### repeat x n times in columns ===> produce an dim(x)*n matrix
rep.col<-function(x,n){
    matrix(rep(x,each=n), ncol=n, byrow=TRUE)
}


