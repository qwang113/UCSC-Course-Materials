rm(list=ls(all=TRUE))
set.seed(41254)
library(MASS)

#####################################
###  Prep data
#####################################
gal <- galaxies/10000  ## vector of obs
J <- length(gal)       ## number of obs


#####################################
###### Set hyperparameter values  #####
#####################################

hpara <- NULL

### number of mixture components
hpara$k <- 5

### p ~ Dir(alpha_1, ..., alpha_k)
hpara$alpha <- rep(1, hpara$k)

### \mu_lk \iid \Nor(\mu_bar, \tau^2)
###  Let me use an empirical approach
###  Set mu_bar at the median of obs
###  Express no information by setting tau2 large.
hpara$mu_bar <- median(gal)
hpara$tau2 <- 10


### \sig2 ~ IG(a, b)
### specify a vauge prior
hpara$a <- 1
hpara$b <- 0.01


#####################################
###  Initialize parameters to run
#####################################
ini_sam <- NULL

### equal prob for components
ini_sam$p <- rep(1/hpara$k, hpara$k)

### means for components
ini_sam$mu <- quantile(gal, prob=seq(0.1, 0.9, length.out=hpara$k))

### auxiliary variable -- component indicator
ini_sam$lam <- sample((1:hpara$k), J, TRUE)

###  mu_lambda
ini_sam$mu_obs <- ini_sam$mu[ini_sam$lam]

### y ~ N(mu, \sig2)
ini_sam$sig2 <- 1




###########################################
##  MCMC parameters
###########################################
n_sam <- 15000
n_burn_in <- 5000
n_thin <- 2

source("fn-mixture-galaxy.R")

### do MCMC
## will pass parameters simulated from the posterior
### 1. mu_lk
### 2. sig2
### 3. p
### 4. lam
### 5. mu_obs
MCMC_sam <- fn.do.MCMC(J, gal, n_sam, hpara, ini_sam)

### mu for each obs
mu_obs <- MCMC_sam$mu_obs[,seq((n_burn_in+1), n_sam, by=n_thin)]
mu_obs_hat <- apply(mu_obs, 1, mean)

### sig2
sig2 <- MCMC_sam$sig2[seq((n_burn_in+1), n_sam, by=n_thin)]

### mu for each obs
mu <- MCMC_sam$mu[,seq((n_burn_in+1), n_sam, by=n_thin)]
p_k <- MCMC_sam$p[,seq((n_burn_in+1), n_sam, by=n_thin)]



pdf("fig/mix-gal-1-trace-5.pdf")
par(mar=c(4.5, 4.5, 2.1, 2.1))
plot(MCMC_sam$mu_obs[1,], type="l", ylab="mean for y1", xlab="Iterations", cex.axis=2, cex.lab=2)
abline(h=gal[1], col=4, lwd=2)
abline(h=mu_obs_hat[1], col=2, lwd=2)
dev.off()

pdf("fig/mix-gal-1-hist-5.pdf")
par(mar=c(4.5, 4.5, 2.1, 2.1))
hist(mu_obs[1,], xlab="mu for obs 1", cex.axis=2, cex.lab=2)
abline(v=gal[1], col=4, lwd=2)
abline(v=mu_obs_hat[1], col=2, lwd=2)
dev.off()


pdf("fig/mix-gal-2-trace-5.pdf")
par(mar=c(4.5, 4.5, 2.1, 2.1))
plot(MCMC_sam$mu_obs[82,], type="l", ylab="mean for y82", xlab="Iterations", cex.axis=2, cex.lab=2)
abline(h=gal[82], col=4, lwd=2)
abline(h=mu_obs_hat[82], col=2, lwd=2)
dev.off()


pdf("fig/mix-gal-2-hist-5.pdf")
par(mar=c(4.5, 4.5, 2.1, 2.1))
hist(mu_obs[82,], xlab="mu for obs 82", cex.axis=2, cex.lab=2)
abline(v=gal[82], col=4, lwd=2)
abline(v=mu_obs_hat[82], col=2, lwd=2)
dev.off()



pdf("fig/mix-gal-sig2-trace-5.pdf")
par(mar=c(4.5, 4.5, 2.1, 2.1))
plot(MCMC_sam$sig2, type="l", ylab="sig2", xlab="Iterations", cex.axis=2, cex.lab=2)
abline(h=mean(sig2), col=4, lwd=4)
dev.off()


pdf("fig/mix-gal-sig2-hist-5.pdf")
par(mar=c(4.5, 4.5, 2.1, 2.1))
hist(sig2, xlab="sig2", cex.axis=2, cex.lab=2)
abline(v=mean(sig2), col=2, lwd=2)
dev.off()



###### posterior inference on f
##### posterior predictive distribution
n_sam <- ncol(mu)

x_grid <- seq(0.5, 4, by=0.01)
x_grid_mat <- rep.row(x_grid, hpara$k)
n_grid <- length(x_grid)
f_sam <- array(NA, dim=c(n_sam, n_grid))
y_pred <- rep(NA, n_sam)
set.seed(9823475)

for(i_sam in 1:n_sam)
{
    mu_i <- rep.col(mu[,i_sam], n_grid)
    p_k_i <- rep.col(p_k[,i_sam], n_grid)
    f_sam[i_sam,] <- apply(dnorm(x_grid_mat, mu_i, sqrt(sig2[i_sam]))*p_k_i, 2, sum)

    ind <- sample((1:hpara$k), 1, TRUE, prob=p_k[,i_sam])
    y_pred[i_sam] <- rnorm(1, mu[ind, i_sam], sqrt(sig2[i_sam]))
}##for(i_sam in 1:n_sam)



f_hat <- apply(f_sam, 2, mean)

f_hat_25 <- apply(f_sam, 2, quantile, prob=0.025)
f_hat_975 <- apply(f_sam, 2, quantile, prob=0.975)


pdf("fig/f_hat.pdf")
par(mar=c(4.5, 4.5, 2.1, 2.1))
# plot
plot(x_grid, f_hat, type = 'n', ylim=c(0, max(f_hat_975)), cex.axis=2, cex.lab=2, ylab="f(y)", xlab="y")
rug(gal, ticksize = 0.05)

polygon(c(rev(x_grid), x_grid), c(rev(f_hat_25), f_hat_975), col=rgb(0, 0, 0.5, 0.5), border = NA) #, col = 'slategray2', border = NA)
lines(x_grid, f_hat, lwd=2, lty=2)
dev.off()


pdf("fig/pred-y.pdf")
par(mar=c(4.5, 4.5, 2.1, 2.1))
hist(y_pred, xlab="y_future", cex.axis=2, cex.lab=2, nclass=30, main="", prob="TRUE", ylim=c(0, 1.5))
#abline(v=c(quantile(y_pred, prob=c(0.025, 0.5, 0.975))), col=2, lty=2, lwd=3)
#abline(v=mean(y_pred), col=4, lty=3, lwd=3)

hist(gal, lwd=4, cex.axis=2, cex.lab=2, prob="TRUE", add=T, col=rgb(0, 0, 0.5, 0.4), nclass=15)
dev.off()
