rm(list=ls(all=TRUE))
set.seed(4444)
library(rmutil)
library(cubature)
library(mvtnorm)

### setup - simulate data
n <- 30 ## sample size
a <- 5
b <- 5
x <- (-1/b*log(runif(n)))^(-1/a) ## simulate data


#### compute normalizing constant
log_sum <- sum(log(x)) ## sum log(x)

fn_NC <- function(alpha, beta)
{
	(alpha)^(n)*(beta)^(n)*exp(-(alpha + 1)*log_sum - beta*sum(x^(-alpha)))
}
tmp <- int2(fn_NC, a=c(0, 0), b=c(Inf, Inf))
tmp

### make a grid of (alpha, beta)
n_grid <- 100
a_grid <- seq(0.01, 10, length.out=100)
b_grid <- seq(0.01, 10, length.out=100)

### evaluate the posterior at the grid of (alpha, beta)
pdf_1 <- array(NA, dim=c(n_grid, n_grid))
for(i_a in 1:n_grid)
{
    for(i_b in 1:n_grid)
    {
        alpha <- a_grid[i_a]
        beta <- b_grid[i_b]
        pdf_1[i_a, i_b] <- (alpha)^(n)*(beta)^(n)*exp(-(alpha + 1)*log_sum - beta*sum(x^(-alpha)))/tmp
    } ## for(i_b in 1:n_grid)
} ## for(i_a in 1:n_grid)


pdf("pdf-1.pdf")
par(mar=c(4.5, 4.5, 2.1, 2.1))
persp(a_grid, b_grid, pdf_1, phi = 45, theta = 30, xlab = "alpha", ylab = "beta", main = "Joint pdf", axes=TRUE, col="white")
dev.off()


pdf("pdf-1-1.pdf")
filled.contour(pdf_1)
dev.off()



# Obtain the maximum and the Hessian at the maximum  -- it minimizes so retrun -r
fn_f <- function(th) {
    r <- n*log(th[1]) + n*log(th[2]) - (th[1]-1)*log_sum - th[2]*sum(x^(-th[1]))
    return(-r)
}


lap <- optim(c(3,3), fn_f, hessian = TRUE)
lap

### evaluate the posterior at the grid of (alpha, beta) using Laplace approx
lap_m <- lap$par
lap_sig <- solve(lap$hessian)

pdf_2 <- array(NA, dim=c(n_grid, n_grid))

for(i_a in 1:n_grid)
{
	for(i_b in 1:n_grid)
	{
		alpha <- a_grid[i_a]
		beta <- b_grid[i_b]
		pdf_2[i_a, i_b] <- dmvnorm(c(alpha, beta), mean = lap_m, sigma = lap_sig, log = FALSE)
    }# for(i_b in 1:n_grid)
}# for(i_a in 1:n_grid)


pdf("pdf-2.pdf")
par(mar=c(4.5, 4.5, 2.1, 2.1))
persp(a_grid, b_grid, pdf_2, phi = 45, theta = 30, xlab = "alpha", ylab = "beta", main = "Joint pdf", axes=TRUE, col="white")
dev.off()


pdf("pdf-2-1.pdf")
filled.contour(pdf_2)
dev.off()



pdf("pdf-diff-1.pdf")
filled.contour(pdf_1-pdf_2)
dev.off()




