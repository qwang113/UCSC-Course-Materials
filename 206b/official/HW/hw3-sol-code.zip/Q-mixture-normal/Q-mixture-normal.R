rm(list=ls(all=TRUE))
set.seed(4444)



######## hyperparamters
K <- 3
mu <- c(-3, 0, 3)
tau2 <- 1
w <- c(1/3, 1/3, 1/3)


### simulate data ####################
# set the number of observations and true value of parameters
n <- 50
sig2 <- 10
th_tr <- 4
x <- rnorm(n, th_tr, sqrt(sig2))


### compute posterior quantities
x_bar <- mean(x)

tau2_1 <- 1/(1/tau2 + n/sig2)
mu_1 <- tau2_1*(x_bar*n/sig2 + mu/tau2)
w_1 <- w*exp(-(x_bar - mu)^2/2/(tau2 + sig2/n))
w_1 <- w_1/sum(w_1)

m <- 5000  ## MC sample size

### posterior distribution of \theta
delta <- sample(1:K, m, TRUE, prob=w_1)  ## sample latent indicators for mixture
post_th <- rnorm(m, mu_1[delta], sqrt(tau2_1))

### evaluate the prior on a grid of \theta
th_grid <- seq(-6.5, 6.5, by=0.1)
prior_den <- w[1]*dnorm(th_grid, mu[1], sqrt(tau2)) + w[2]*dnorm(th_grid, mu[2], sqrt(tau2)) + w[3]*dnorm(th_grid, mu[3], sqrt(tau2))


pdf("c-post-th.pdf")
par(mar=c(4.5, 4.5, 2.1, 2.1))
hist(post_th, probability=TRUE, xlim=c(-6.5, 6.5), xlab="theta", cex.axis=2, cex.lab=2)
abline(v=th_tr, col=4, lwd=4, lty=2)
lines(th_grid, prior_den, col=2, lwd=2, lty=2)
dev.off()


#plot(th_grid, prior_den, col=2, lwd=2, lty=2)


## posterior predictive distribution
pred_x <- rnorm(m, mu_1[delta], sqrt(tau2_1 + sig2))

x_grid <- seq(-20, 40, by=0.1)
norm_den <- dnorm(x_grid, th_tr, sqrt(sig2))


pdf("c-post-pred.pdf")
par(mar=c(4.5, 4.5, 2.1, 2.1))
hist(pred_x, probability=TRUE, xlab="x", cex.axis=2, cex.lab=2)
lines(x_grid, norm_den, col=2, lwd=2, lty=2)
dev.off()




### simulate data ####################
# set the number of observations and true value of parameters
n <- 50
sig2 <- 10
th_tr <- 1.5
x <- rnorm(n, th_tr, sqrt(sig2))

### compute posterior quantities
x_bar <- mean(x)

tau2_1 <- 1/(1/tau2 + n/sig2)
mu_1 <- tau2_1*(x_bar*n/sig2 + mu/tau2)
w_1 <- w*exp(-(x_bar - mu)^2/2/(tau2 + sig2/n))
w_1 <- w_1/sum(w_1)

m <- 5000 # MC sample size

### posterior distribution of \theta
delta <- sample(1:K, m, TRUE, prob=w_1)  ## sample latent indicators for mixture
post_th <- rnorm(m, mu_1[delta], sqrt(tau2_1))

## evaluate the prior on a grid of theta
th_grid <- seq(-6.5, 6.5, by=0.1)
prior_den <- w[1]*dnorm(th_grid, mu[1], sqrt(tau2)) + w[2]*dnorm(th_grid, mu[2], sqrt(tau2)) + w[3]*dnorm(th_grid, mu[3], sqrt(tau2))


pdf("d-post-th.pdf")
par(mar=c(4.5, 4.5, 2.1, 2.1))
hist(post_th, probability=TRUE, xlim=c(-6.5, 6.5), xlab="theta", cex.axis=2, cex.lab=2)
abline(v=th_tr, col=4, lwd=4, lty=2)
lines(th_grid, prior_den, col=2, lwd=2, lty=2)
dev.off()

#plot(th_grid, prior_den, col=2, lwd=2, lty=2)


## posterior predictive distrubiton
pred_x <- rnorm(m, mu_1[delta], sqrt(tau2_1 + sig2))

x_grid <- seq(-20, 40, by=0.1)
norm_den <- dnorm(x_grid, th_tr, sqrt(sig2))

pdf("d-post-pred.pdf")
par(mar=c(4.5, 4.5, 2.1, 2.1))
hist(pred_x, probability=TRUE, xlab="x", cex.axis=2, cex.lab=2)
lines(x_grid, norm_den, col=2, lwd=2, lty=2)
dev.off()


