rm(list=ls(all=TRUE))
set.seed(4444)

### simulate data ####################
# set the number of observations and true value of parameters
n <- 1000
tr_th <- 5
tr_sig2 <- 1

# generate dataset
x <- rnorm(n, tr_th, sqrt(tr_sig2))
### END: simulate data ####################


fn_post_eta <- function(dat_x, n_dat, n_sam, th_0, k_0, a_0, b_0)
{
    # th_0 <- tr_th; k_0 <- k0; a_0 <- a; b_0 <- b; dat_x <- x; n_dat <- n; n_sam <- N_sam
    
    ## simulate sig2
    alpha <- a_0 + n_dat/2
    x_bar <- mean(dat_x)
    beta <- b_0 + sum((dat_x - x_bar)^2)/2 + n_dat*(x_bar - th_0)^2/2/(n_dat*k_0 + 1)
    sig2_1 <- (1/rgamma(n_sam, alpha, beta))
    
    #calculate posterior parameters
    v <- 1/(n_dat/sig2_1 + 1/k_0/sig2_1)
    m <- (th_0/k_0 + n_dat*x_bar)/(1/k_0 + n_dat)
    th_1 <- rnorm(n_sam, m, sqrt(v))
    
    return(th_1/sqrt(sig2_1))
}

## MC sample size
N_sam <- 5000

#i. fairly informative priors around the true values of both parameters
th0 <- tr_th
k0 <- 0.01
a <- 1001
b <- 1000

eta_post <- fn_post_eta(x, n, N_sam, th0, k0, a, b)
round(c(mean(eta_post), quantile(eta_post, prob=c(0.025, 0.975))), 3)
#END: i. fairly informative priors around the true values of both parameters


#ii. informative prior on \theta and vague on \sigma^2
th0 <- tr_th
k0 <- 0.01
a <- 0.1
b <- 0.1

eta_post <- fn_post_eta(x, n, N_sam, th0, k0, a, b)
round(c(mean(eta_post), quantile(eta_post, prob=c(0.025, 0.975))), 3)
#END: ii. informative prior on \theta and vague on \sigma^2



#iii. informative prior on \sig2 and vague on \theta
th0 <- tr_th
k0 <- 100
a <- 1001
b <- 1000

eta_post <- fn_post_eta(x, n, N_sam, th0, k0, a, b)
round(c(mean(eta_post), quantile(eta_post, prob=c(0.025, 0.975))), 3)
#END: iii. informative prior on \sig2 and vague on \theta


# v. vague on both parameters
th0 <- tr_th
k0 <- 100
a <- 1001
b <- 1000

eta_post <- fn_post_eta(x, n, N_sam, th0, k0, a, b)
round(c(mean(eta_post), quantile(eta_post, prob=c(0.025, 0.975))), 3)
#END: v. vague on both parameters

