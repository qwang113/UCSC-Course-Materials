rm(list=ls(all=TRUE))
set.seed(4444)
library(rmutil)
library(cubature)

### prior: \theta \sim Be(1/2, 1/2)
a <- 1/2
b <- 1/2

#### likelihood: x \mid \theta \sim Binom(n, \theta)
n <- 1000
x <- 100

#### posterior: \theta \mid x \sim Be(a + x, b+n-x
a_post <- a + x
b_post <- b + n - x

#### (a) exact posterior
round(c(qbeta(.025, a_post, b_post),qbeta(.975, a_post, b_post)), 3)
#### END: (a) exact posterior


#### (b) Laplace approximation
# calculate the MAP - th0
th0 <- (a_post - 1)/(a_post + b_post - 2)

# evaluate the first and second derivaties at the MAP
q0 <- exp((a_post - 1)*log(th0) + (b_post - 1)*log(1 - th0))
A_inv <- (a_post - 1)*(b_post - 1)/(a_post + b_post - 2)^3

#calculate the constant
Const <- q0*sqrt(2*pi*A_inv)/beta(a_post, b_post)


# compute the interval
lower <- qnorm((1 - 0.95/Const)/2, th0, sqrt(A_inv))
upper <- qnorm((1 - 0.95/Const)/2, th0, sqrt(A_inv), lower.tail=FALSE)

round(c(lower, upper), 3)
####  END: (b) Laplace approximation


#### (c) Monte Carlo simulation
th <- rbeta(2000, a_post, b_post)
round(quantile(th, probs=c(0.025, 0.975)), 3)
#### END: (c) Monte Carlo simulation


