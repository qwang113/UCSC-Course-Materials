rm(list=ls(all=TRUE))
set.seed(4444)


# set number of M-H samples and true value of the parameters
N_sam <- 1000
th1 <- 1.5
th2 <- 2
# calculate teorethical means of Z and 1/Z
sqrt(th2/th1)
sqrt(th2/th1) + 1/(2*th2)

# initialize chain
MH_RW <- rep(NA, N_sam)
v <- 0.5
accpt_cnt <- 0
z_cur <- 1.0

# do M-H
for(i_sam in 1:N_sam) {
    
    # evaluate the pdf at the current value of z + Jacobian
    p_cur <- -(1/2)*log(z_cur) - th1*z_cur - th2/z_cur

    ## draw a proposal
    z_pro <- exp(log(z_cur) + rnorm(1, 0, sqrt(v)))
    
    # evaluate the pdf at the proposed value of z + Jacobian
    p_pro <- -(1/2)*log(z_pro) - th1*z_pro - th2/z_pro # calculate acceptance probability
    
    ## evaluate the accptance prob.
    accpt_prob <- p_pro - p_cur
    
    # accept or reject acordingly
    if(log(runif(1)) < accpt_prob) {
        z_cur <- z_pro
        accpt_cnt <- accpt_cnt + 1
    }
    
    MH_RW[i_sam] <- z_cur
} ## for(i_sam in 1:N_sam) {


# calculare MC estimates of the mean of Z and 1/Z -- truth:  1.154701 and 1.404701
mean(MH_RW)
mean(1/MH_RW)


## accptance rate
accpt_cnt/N_sam

