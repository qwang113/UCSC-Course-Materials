rm(list=ls(all=TRUE))
set.seed(4444)


# set number of M-H samples and true value of the parameters
N_sam <- 1000
th1 <- 1.5
th2 <- 2
# calculate teorethical means of Z and 1/Z
sqrt(th2/th1)
sqrt(th2/th1) + 1/(2*th2)

# set hyperparameters - for the proposal distributions
b <- 1
a <- 1

# initialize chain
MH_indep <- rep(NA, N_sam)
accpt_cnt <- 0
z_cur <- 1.0

# do M-H
for(i_sam in 1:N_sam) {
    
    # evaluate the pdf at the current value of z
    p_cur <- -(3/2)*log(z_cur) - th1*z_cur - th2/z_cur

    ## draw a proposal
    z_pro <- rgamma(1, a, b)
    
    # evaluate the pdf at the proposed value of z
    p_pro <- -(3/2)*log(z_pro) - th1*z_pro - th2/z_pro # calculate acceptance probability
    
    ## evaluate the accptance prob.
    accpt_prob <- p_pro + dgamma(z_cur, a, b, log=T) - p_cur - dgamma(z_pro, a, b, log=T)
    
    # accept or reject acordingly
    if(log(runif(1)) < accpt_prob) {
        z_cur <- z_pro
        accpt_cnt <- accpt_cnt + 1
    }
    
    MH_indep[i_sam] <- z_cur
} ## for(i_sam in 1:N_sam) {


# calculare MC estimates of the mean of Z and 1/Z -- truth:  1.154701 and 1.404701
mean(MH_indep)
mean(1/MH_indep)


## accptance rate
accpt_cnt/N_sam


pdf("hist-m.pdf")
par(mar=c(4.5, 4.5, 2.1, 2.1))
hist(MH_indep, lwd=4, xlab="Z", cex.axis=2, cex.lab=2, main="")
abline(v=c(sqrt(th2/th1)), col=2, lwd=2, lty=1)
abline(v=c(mean(MH_indep)), col=4, lwd=2, lty=2)
legend("topright", legend=c("Truth", "MC Approx"), col=c(2, 4), cex=2, lwd=2, bty="n", lty=c(1, 2))
dev.off()


pdf("hist-inv-m.pdf")
par(mar=c(4.5, 4.5, 2.1, 2.1))
hist(1/MH_indep, lwd=4, xlab="1/Z", cex.axis=2, cex.lab=2, main="")
abline(v=c(sqrt(th2/th1) + 1/(2*th2)), col=2, lwd=2, lty=1)
abline(v=c(mean(1/MH_indep)), col=4, lwd=2, lty=2)
legend("topright", legend=c("Truth", "MC Approx"), col=c(2, 4), cex=2, lwd=2, bty="n", lty=c(1, 2))
dev.off()

### evaluate the target and proposal densities at a grid of z
z_grid <- seq(0.01, 10, by=0.01)
f_IG <- exp(-(3/2)*log(z_grid) - th1*z_grid - th2/z_grid + 2*sqrt(th1*th2) + log(sqrt(2*th2)))/sqrt(2*pi)
f_pro <- dgamma(z_grid, a, b)

pdf("den-compare.pdf")
par(mar=c(4.5, 4.5, 2.1, 2.1))
plot(z_grid, f_IG, type="l", lwd=4, xlab="z", cex.axis=2, cex.lab=2, ylab="density", ylim=c(0, max(c(f_IG, f_pro))))
lines(z_grid, f_pro, lwd=4, col=2, lty=2)
legend("topright", legend=c("Target", "Proposal"), col=c(1, 2), cex=2, lwd=2, bty="n", lty=c(1, 2))
dev.off()



#### TRY with different proposal -- CASE2
rm(list=ls(all=TRUE))
set.seed(4444)


# set number of M-H samples and true value of the parameters
N_sam <- 1000
th1 <- 1.5
th2 <- 2
# calculate teorethical means of Z and 1/Z
sqrt(th2/th1)
sqrt(th2/th1) + 1/(2*th2)

# set hyperparameters - for the proposal distributions
b <- 0.1
a <- 0.1

# initialize chain
MH_indep <- rep(NA, N_sam)
accpt_cnt <- 0
z_cur <- 1.0

# do M-H
for(i_sam in 1:N_sam) {
    
    # evaluate the pdf at the current value of z
    p_cur <- -(3/2)*log(z_cur) - th1*z_cur - th2/z_cur
    
    ## draw a proposal
    z_pro <- rgamma(1, a, b)
    
    # evaluate the pdf at the proposed value of z
    p_pro <- -(3/2)*log(z_pro) - th1*z_pro - th2/z_pro # calculate acceptance probability
    
    ## evaluate the accptance prob.
    accpt_prob <- p_pro + dgamma(z_cur, a, b, log=T) - p_cur - dgamma(z_pro, a, b, log=T)
    
    # accept or reject acordingly
    if(log(runif(1)) < accpt_prob) {
        z_cur <- z_pro
        accpt_cnt <- accpt_cnt + 1
    }
    
    MH_indep[i_sam] <- z_cur
} ## for(i_sam in 1:N_sam) {


# calculare MC estimates of the mean of Z and 1/Z -- truth:  1.154701 and 1.404701
mean(MH_indep)

mean(1/MH_indep)

## accptance rate
accpt_cnt/N_sam


pdf("hist-m-1.pdf")
par(mar=c(4.5, 4.5, 2.1, 2.1))
hist(MH_indep, lwd=4, xlab="Z", cex.axis=2, cex.lab=2, main="")
abline(v=c(sqrt(th2/th1)), col=2, lwd=2, lty=1)
abline(v=c(mean(MH_indep)), col=4, lwd=2, lty=2)
legend("topright", legend=c("Truth", "MC Approx"), col=c(2, 4), cex=2, lwd=2, bty="n", lty=c(1, 2))
dev.off()


pdf("hist-inv-m-1.pdf")
par(mar=c(4.5, 4.5, 2.1, 2.1))
hist(1/MH_indep, lwd=4, xlab="1/Z", cex.axis=2, cex.lab=2, main="")
abline(v=c(sqrt(th2/th1) + 1/(2*th2)), col=2, lwd=2, lty=1)
abline(v=c(mean(1/MH_indep)), col=4, lwd=2, lty=2)
legend("topright", legend=c("Truth", "MC Approx"), col=c(2, 4), cex=2, lwd=2, bty="n", lty=c(1, 2))
dev.off()

### evaluate the target and proposal densities at a grid of z
z_grid <- seq(0.01, 10, by=0.01)
f_IG <- exp(-(3/2)*log(z_grid) - th1*z_grid - th2/z_grid + 2*sqrt(th1*th2) + log(sqrt(2*th2)))/sqrt(2*pi)
f_pro <- dgamma(z_grid, a, b)

pdf("den-compare-1.pdf")
par(mar=c(4.5, 4.5, 2.1, 2.1))
plot(z_grid, f_IG, type="l", lwd=4, xlab="z", cex.axis=2, cex.lab=2, ylab="density", ylim=c(0, max(c(f_IG, f_pro))))
lines(z_grid, f_pro, lwd=4, col=2, lty=2)
legend("topright", legend=c("Target", "Proposal"), col=c(1, 2), cex=2, lwd=2, bty="n", lty=c(1, 2))
dev.off()




#### TRY with different proposal-- CASE3
rm(list=ls(all=TRUE))
set.seed(4444)


# set number of M-H samples and true value of the parameters
N_sam <- 1000
th1 <- 1.5
th2 <- 2
# calculate teorethical means of Z and 1/Z
sqrt(th2/th1)
sqrt(th2/th1) + 1/(2*th2)

# set hyperparameters - for the proposal distributions
b <- 1
a <- 5

# initialize chain
MH_indep <- rep(NA, N_sam)
accpt_cnt <- 0
z_cur <- 1.0

# do M-H
for(i_sam in 1:N_sam) {
    
    # evaluate the pdf at the current value of z
    p_cur <- -(3/2)*log(z_cur) - th1*z_cur - th2/z_cur
    
    ## draw a proposal
    z_pro <- rgamma(1, a, b)
    
    # evaluate the pdf at the proposed value of z
    p_pro <- -(3/2)*log(z_pro) - th1*z_pro - th2/z_pro # calculate acceptance probability
    
    ## evaluate the accptance prob.
    accpt_prob <- p_pro + dgamma(z_cur, a, b, log=T) - p_cur - dgamma(z_pro, a, b, log=T)
    
    # accept or reject acordingly
    if(log(runif(1)) < accpt_prob) {
        z_cur <- z_pro
        accpt_cnt <- accpt_cnt + 1
    }
    
    MH_indep[i_sam] <- z_cur
} ## for(i_sam in 1:N_sam) {


# calculare MC estimates of the mean of Z and 1/Z -- truth:  1.154701 and 1.404701
mean(MH_indep)

mean(1/MH_indep)

## accptance rate
accpt_cnt/N_sam


pdf("hist-m-2.pdf")
par(mar=c(4.5, 4.5, 2.1, 2.1))
hist(MH_indep, lwd=4, xlab="Z", cex.axis=2, cex.lab=2, main="")
abline(v=c(sqrt(th2/th1)), col=2, lwd=2, lty=1)
abline(v=c(mean(MH_indep)), col=4, lwd=2, lty=2)
legend("topright", legend=c("Truth", "MC Approx"), col=c(2, 4), cex=2, lwd=2, bty="n", lty=c(1, 2))
dev.off()


pdf("hist-inv-m-2.pdf")
par(mar=c(4.5, 4.5, 2.1, 2.1))
hist(1/MH_indep, lwd=4, xlab="1/Z", cex.axis=2, cex.lab=2, main="")
abline(v=c(sqrt(th2/th1) + 1/(2*th2)), col=2, lwd=2, lty=1)
abline(v=c(mean(1/MH_indep)), col=4, lwd=2, lty=2)
legend("topright", legend=c("Truth", "MC Approx"), col=c(2, 4), cex=2, lwd=2, bty="n", lty=c(1, 2))
dev.off()

### evaluate the target and proposal densities at a grid of z
z_grid <- seq(0.01, 10, by=0.01)
f_IG <- exp(-(3/2)*log(z_grid) - th1*z_grid - th2/z_grid + 2*sqrt(th1*th2) + log(sqrt(2*th2)))/sqrt(2*pi)
f_pro <- dgamma(z_grid, a, b)

pdf("den-compare-2.pdf")
par(mar=c(4.5, 4.5, 2.1, 2.1))
plot(z_grid, f_IG, type="l", lwd=4, xlab="z", cex.axis=2, cex.lab=2, ylab="density", ylim=c(0, max(c(f_IG, f_pro))))
lines(z_grid, f_pro, lwd=4, col=2, lty=2)
legend("topright", legend=c("Target", "Proposal"), col=c(1, 2), cex=2, lwd=2, bty="n", lty=c(1, 2))
dev.off()









