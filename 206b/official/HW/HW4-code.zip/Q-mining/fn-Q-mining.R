fn_run_MCMC <- function(n_burn, n_sam, n_thin, dat, hpara, cur_sam)
{
    ### sum of y
    cumsum_y <- cumsum(dat$y)  ### \sum_{i=1}^m y_i
    cumsum_y <- cbind(cumsum_y, sum(dat$y) - cumsum_y)  ## ### \sum_{i=m+1}^n y_i
    
    a_y_sum <- cumsum_y[,1] + hpara$alpha ### \sum_{i=1}^m y_i + \alpha
    lgam_a_y_sum <- lgamma(a_y_sum)       ### log(\sum_{i=1}^m y_i + \alpha)
    
    b_y_sum <- cumsum_y[,2] + hpara$gam  ## ### \sum_{i=m+1}^n y_i + \gamma
    lgam_b_y_sum <- lgamma(b_y_sum)      ## ### log(\sum_{i=m+1}^n y_i + \gamma)

    m_grid <- (1:dat$n)  ## I use all possible values of m to update m.
    
    # sampling --- burn-in
    for(i_iter in 1:n_burn)
    {
        # update theta from its full conditional
        cur_sam$th <- rgamma(1, cumsum_y[cur_sam$m,1] + hpara$alpha, cur_sam$m + hpara$beta)
        
        # update phi from its full conditional
        cur_sam$phi <- rgamma(1, cumsum_y[cur_sam$m, 2] + hpara$gam, (dat$n - cur_sam$m + hpara$delta))
        
        ## update m from a grid of (1:n) -- here I consider all possible values of m since the data size is small
        ## if data size is large, we may use a MH step
        my_prob <- lgam_a_y_sum - (a_y_sum)*log(m_grid + hpara$beta) + lgam_b_y_sum - (b_y_sum)*log(dat$n - m_grid + hpara$delta)
        my_prob <- exp(my_prob - max(my_prob))
        cur_sam$m <- sample(m_grid, 1, FALSE, prob=my_prob)
    } ### for(i_iter in 1:n_burn)
    
    ### save MC samples
    save_sam <- NULL
    save_sam$m <- rep(NA, n_sam)
    save_sam$th <- rep(NA, n_sam)
    save_sam$phi <- rep(NA, n_sam)

    # sampling
    i_sam <- 1
    for(i_iter in 1:(n_sam*n_thin))
    {
        # update theta from its full conditional
        cur_sam$th <- rgamma(1, cumsum_y[cur_sam$m,1] + hpara$alpha, cur_sam$m + hpara$beta)
        
        # update phi from its full conditional
        cur_sam$phi <- rgamma(1, cumsum_y[cur_sam$m, 2] + hpara$gam, (dat$n - cur_sam$m + hpara$delta))
        
        ## update m from a grid of (1:n) -- here I consider all possible values of m since the data size is small
        ## if data size is large, we may use a MH step
        my_prob <- lgam_a_y_sum - (a_y_sum)*log(m_grid + hpara$beta) + lgam_b_y_sum - (b_y_sum)*log(dat$n - m_grid + hpara$delta)
        my_prob <- exp(my_prob - max(my_prob))
        cur_sam$m <- sample(m_grid, 1, FALSE, prob=my_prob)
        
        if((i_iter%%n_thin) == 0)
        {
            save_sam$m[i_sam] <- cur_sam$m
            save_sam$th[i_sam] <- cur_sam$th
            save_sam$phi[i_sam] <- cur_sam$phi
            i_sam <- i_sam + 1
        } ### if((iter%%n_thin) == 0)
        
    } ### for(i_iter in 1:(n_sam*n_thin))
    
    return(save_sam)
}
