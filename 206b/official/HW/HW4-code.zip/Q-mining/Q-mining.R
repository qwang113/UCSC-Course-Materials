rm(list=ls(all=TRUE))
set.seed(4444)

source("mining-data.R") ### data: y and sample size: n
mydat <- NULL
mydat$y <- y
mydat$n <- n

## read in functions needed
source("fn-Q-mining.R")


# specify hyperparameters. In this case using the data.
hyper <- NULL
### th ~ Ga(alpha, beta)
hyper$alpha <- 0.1
hyper$beta <- 0.1
### phi ~ Ga(gam, delta)
hyper$gam <- 0.1
hyper$delta <- 0.1

# set up MCMC variables
N_sam <- 5000
N_burn <- 5000
N_thin <- 3 ### save every three other draw

# initialize chains -- draws from the prior
ini_sam <- NULL
ini_sam$th <- rgamma(1, hyper$alpha, hyper$beta)
ini_sam$phi <- rgamma(1, hyper$gam, hyper$delta)
ini_sam$m <- sample((1:mydat$n), 1)


## do MCMC and save sam
mc_sam <- fn_run_MCMC(N_burn, N_sam, N_thin, mydat, hyper, ini_sam)

### check convergence and mixing
pdf("check.pdf")
par(mfrow=c(3,1))
plot(1:N_sam, mc_sam$m, type="l")
plot(1:N_sam, mc_sam$th, type="l")
plot(1:N_sam, mc_sam$ph, type="l")
dev.off()


### post distribution of m
post_dist_m <- as.matrix((table(c((1:mydat$n), mc_sam$m))-1)/N_sam)

# plot evolution of y along with MAP of m
pdf("dat.pdf")
par(mar=c(4.5, 4.5, 2.1, 2.1))
plot((1:mydat$n), mydat$y, cex=2, lwd=2, type="o", main="", cex.axis=1.5, cex.lab=1.5, xlab="year", ylab="y")
abline(v=which.max(post_dist_m), lty=2, lwd=3, col=2) ### at MAP of m
dev.off()

# plot post dist of m
pdf("post-m.pdf")
par(mar=c(4.5, 4.5, 2.1, 2.1))
plot((1:mydat$n), post_dist_m, cex=2, lwd=2, type="o", main="", cex.axis=1.5, cex.lab=1.5, xlab="year", ylab="post prob of m")
abline(v=which.max(post_dist_m), lty=2, lwd=3, col=2) ### at MAP of m
dev.off()

pdf("post-th.pdf")
par(mar=c(4.5, 4.5, 2.1, 2.1))
hist(mc_sam$th, col=8, lwd=2, , main="", cex.axis=1.5, cex.lab=1.5, xlab="theta")
abline(v=c(mean(mc_sam$th), quantile(mc_sam$th, prob=c(0.025, 0.975))), lty=2, lwd=3, col=2)
dev.off()


pdf("post-phi.pdf")
par(mar=c(4.5, 4.5, 2.1, 2.1))
hist(mc_sam$phi, col=8, lwd=2, , main="", cex.axis=1.5, cex.lab=1.5, xlab="phi")
abline(v=c(mean(mc_sam$phi), quantile(mc_sam$phi, prob=c(0.025, 0.975))), lty=2, lwd=3, col=2)
dev.off()


