rm(list=ls(all=TRUE))
set.seed(4444)
## read in functions needed
source("fn-Q5-Souza.R")


# read data and calculate statistics
dat_1 <- read.csv("Q5-madeup-data.csv", header=TRUE)

dat <- NULL
dat$x <- dat_1$time
dat$y <- dat_1$weight
dat$n <- max(dat_1$patient)
dat$m <- rep(NA, dat$n)
dat$sum_t2 <- rep(NA, dat$n)
dat$visit <- dat_1$visit
dat$pa <- dat_1$patient


for(i_pa in 1:dat$n)
{
    dat$sum_t2[i_pa] <- sum((dat_1$time[dat_1$patient == i_pa])^2)  ## \sum_j t^2_ij for each i
    dat$m[i_pa] <- sum(dat_1$patient == i_pa)
}##for(i_pa in 1:dat$n)

dat$NN <- sum(dat$m)

### fixed hyperparameters
hyper <- NULL
hyper$P_alpha <- 10000
hyper$P_beta <- 10000
hyper$a <- 0.1
hyper$b <- 0.1

### initialize MC
cur_sam <- NULL
cur_sam$alpha_pa <- cur_sam$beta_pa <- rep(NA, dat$n)

for(i_pa in 1:dat$n)
{
    tmp <- summary(lm(dat$y[dat$pa==i_pa] ~ 1 + dat$x[dat$pa==i_pa]))
    cur_sam$alpha_pa[i_pa] <- tmp$coefficients[1,1]
    cur_sam$beta_pa[i_pa] <- tmp$coefficients[1,2]
}##for(i_pa in 1:dat$n)

cur_sam$alpha_bar <- mean(cur_sam$alpha_pa)
cur_sam$beta_bar <- mean(cur_sam$beta_pa)
cur_sam$tau_alpha <- 100
cur_sam$tau_beta <- 100
cur_sam$sig2 <- 100



## MCMC para
N_iter <- 9000
N_burn <- 3000
N_thin <- 2

## save MC sam
MCMC_sam <- NULL
MCMC_sam$alpha <- MCMC_sam$beta <- MCMC_sam$tau_alpha <- MCMC_sam$tau_beta <- MCMC_sam$sig2 <- rep(NA, N_iter)
MCMC_sam$alpha_pa <- array(NA, dim=c(dat$n, N_iter))
MCMC_sam$beta_pa <- array(NA, dim=c(dat$n, N_iter))

## Do MCMC
set.seed(9978879)
for(i_iter in 1:N_iter)
{
    if((i_iter%%1000)==0)
    {
        print(paste("i.iter=", i_iter))
        print(date())
    }
    
    ## update alpha
    cur_sam$alpha <- fn_update_alpha(dat$n, cur_sam$tau_alpha, hyper$P_alpha, sum(cur_sam$alpha_pa))

    ## update beta
    cur_sam$beta <- fn_update_alpha(dat$n, cur_sam$tau_beta, hyper$P_beta, sum(cur_sam$beta_pa))

    ## udpate tau_alpha
    cur_sam$tau_alpha <- fn_update_tau(hyper$a, hyper$b, dat$n, sum((cur_sam$alpha_pa - cur_sam$alpha)^2))

    ## udpate tau_beta
    cur_sam$tau_beta <- fn_update_tau(hyper$a, hyper$b, dat$n, sum((cur_sam$beta_pa - cur_sam$beta)^2))

    ## update sig2
    cur_sam$sig2 <- fn_update_tau(hyper$a, hyper$b, dat$NN, sum((dat$y - cur_sam$alpha_pa[dat$pa] - cur_sam$beta_pa[dat$pa]*dat$x)^2))

    ## update alpha_i
    cur_sam$alpha_pa <- fn_update_alpha_pa(dat$pa, dat$m, dat$n, cur_sam$tau_alpha, cur_sam$sig2, cur_sam$alpha, (dat$y - cur_sam$beta_pa[dat$pa]*dat$x))

    ## update beta_i
    cur_sam$beta_pa <- fn_update_alpha_pa(dat$pa, dat$sum_t2, dat$n, cur_sam$tau_beta, cur_sam$sig2, cur_sam$beta, ((dat$y - cur_sam$alpha_pa[dat$pa])*dat$x))

    ## save current sample
    MCMC_sam$alpha[i_iter] <- cur_sam$alpha
    MCMC_sam$beta[i_iter] <- cur_sam$beta
    MCMC_sam$tau_alpha[i_iter] <- cur_sam$tau_alpha
    MCMC_sam$tau_beta[i_iter] <- cur_sam$tau_beta
    MCMC_sam$sig2[i_iter] <- cur_sam$sig2
    MCMC_sam$alpha_pa[,i_iter] <- cur_sam$alpha_pa
    MCMC_sam$beta_pa[,i_iter] <- cur_sam$beta_pa
} ## for(i_iter in 1:N_iter)



pdf("mixing-check.pdf")
par(mfrow=c(2,2))
plot(MCMC_sam$alpha, col=1, type="l", main="", cex.axis=1.5, cex.lab=1.5, ylab="alpha")
plot(MCMC_sam$beta, col=1, type="l", main="", cex.axis=1.5, cex.lab=1.5, ylab="beta")

plot(MCMC_sam$tau_alpha, col=1, type="l", main="", cex.axis=1.5, cex.lab=1.5, ylab="tau_alpha")
plot(MCMC_sam$tau_beta, col=1, type="l", main="", cex.axis=1.5, cex.lab=1.5, ylab="tau_beta")

plot(MCMC_sam$sig2, col=1, type="l", main="", cex.axis=1.5, cex.lab=1.5, ylab="sig2")

par(mfrow=c(3,2))
for(i_pa in 1:dat$n)
{
    plot(MCMC_sam$alpha_pa[i_pa,], col=1, type="l", cex.axis=1.5, cex.lab=1.5, ylab="alpha_i", main=i_pa)
    plot(MCMC_sam$beta_pa[i_pa,], col=1, type="l", cex.axis=1.5, cex.lab=1.5, ylab="beta_i", main=i_pa)
}##for(i_pa in 1:dat$n)
dev.off()




## burn-in and thining
sam_1 <- NULL
sam_1$alpha <- MCMC_sam$alpha[seq((N_burn + 1), N_iter, by=N_thin)]
sam_1$beta <- MCMC_sam$beta[seq((N_burn + 1), N_iter, by=N_thin)]

sam_1$tau_alpha <- MCMC_sam$tau_alpha[seq((N_burn + 1), N_iter, by=N_thin)]
sam_1$tau_beta <- MCMC_sam$tau_beta[seq((N_burn + 1), N_iter, by=N_thin)]

sam_1$sig2 <- MCMC_sam$sig2[seq((N_burn + 1), N_iter, by=N_thin)]

sam_1$alpha_pa <- MCMC_sam$alpha_pa[,seq((N_burn + 1), N_iter, by=N_thin)]
sam_1$beta_pa <- MCMC_sam$beta_pa[,seq((N_burn + 1), N_iter, by=N_thin)]



# posterior distributions
pdf("post-alpha.pdf")
par(mar=c(4.5, 4.5, 2.1, 2.1))
hist(sam_1$alpha, main="", cex.axis=1.5, cex.lab=1.5, xlab="alpha")
abline(v=c(mean(sam_1$alpha), quantile(sam_1$alpha, probs=c(0.025, 0.975))), col=2, lwd=4, lty=2)
dev.off()

pdf("post-beta.pdf")
par(mar=c(4.5, 4.5, 2.1, 2.1))
hist(sam_1$beta, main="", cex.axis=1.5, cex.lab=1.5, xlab="beta")
abline(v=c(mean(sam_1$beta), quantile(sam_1$beta, probs=c(0.025, 0.975))), col=2, lwd=4, lty=2)
dev.off()

pdf("post-tau-alpha.pdf")
par(mar=c(4.5, 4.5, 2.1, 2.1))
hist(sam_1$tau_alpha, main="", cex.axis=1.5, cex.lab=1.5, xlab="tau_alpha")
abline(v=c(mean(sam_1$tau_alpha), quantile(sam_1$tau_alpha, probs=c(0.025, 0.975))), col=2, lwd=4, lty=2)
dev.off()

pdf("post-tau-beta.pdf")
par(mar=c(4.5, 4.5, 2.1, 2.1))
hist(sam_1$tau_beta, main="", cex.axis=1.5, cex.lab=1.5, xlab="tau-beta")
abline(v=c(mean(sam_1$tau_beta), quantile(sam_1$tau_beta, probs=c(0.025, 0.975))), col=2, lwd=4, lty=2)
dev.off()


pdf("post-sig2.pdf")
par(mar=c(4.5, 4.5, 2.1, 2.1))
hist(sam_1$sig2, main="", cex.axis=1.5, cex.lab=1.5, xlab="sig2")
abline(v=c(mean(sam_1$sig2), quantile(sam_1$sig2, probs=c(0.025, 0.975))), col=2, lwd=4, lty=2)
dev.off()

alpha_pa_hat <- cbind(apply(sam_1$alpha_pa, 1, mean), t(apply(sam_1$alpha_pa, 1, quantile, prob=c(0.025, 0.975))))
beta_pa_hat <- cbind(apply(sam_1$beta_pa, 1, mean), t(apply(sam_1$beta_pa, 1, quantile, prob=c(0.025, 0.975))))


pdf("alpha_i.pdf", width=8, height=4)
par(mar=c(4.5, 4.5, 2.1, 2.1))
plot(1:dat$n, alpha_pa_hat[,1], cex=1.5, pch=19, cex.axis=1.5, cex.lab=1.5, ylim=c(min(alpha_pa_hat), max(alpha_pa_hat)), ylab="alpha_i", xlab="patient no")

abline(h=c(mean(sam_1$alpha), quantile(sam_1$alpha, probs=c(0.025, 0.975))), col=2, lwd=1.5, lty=2)

for(i_pa in 1:dat$n)
{
    segments(i_pa, alpha_pa_hat[i_pa, 2], x1 = i_pa, y1 = alpha_pa_hat[i_pa, 3], col=4, lty=1, lwd=2)
}

points(1:dat$n, alpha_pa_hat[,1], cex=1.5, pch=19)


dev.off()



pdf("beta_i.pdf", width=8, height=4)
par(mar=c(4.5, 4.5, 2.1, 2.1))
plot(1:dat$n, beta_pa_hat[,1], cex=1.5, pch=19, cex.axis=1.5, cex.lab=1.5, ylim=c(min(beta_pa_hat), max(beta_pa_hat)), ylab="beta_i", xlab="patient no")

abline(h=c(mean(sam_1$beta), quantile(sam_1$beta, probs=c(0.025, 0.975))), col=2, lwd=1.5, lty=2)

for(i_pa in 1:dat$n)
{
    segments(i_pa, beta_pa_hat[i_pa, 2], x1 = i_pa, y1 = beta_pa_hat[i_pa, 3], col=4, lty=1, lwd=2)
}

points(1:dat$n, beta_pa_hat[,1], cex=1.5, pch=19)


dev.off()


