## update alpha
fn_update_alpha <- function(n, tau_alpha, P_alpha, sum_alpha_pa)
{
    # n <- dat$n; tau_alpha <- cur_sam$tau_alpha; P_alpha <- hyper$P_alpha; sum_alpha_pa <- sum(cur_sam$alpha_pa)
    v2 <- 1.0/(n/tau_alpha + 1.0/P_alpha)
    m <- v2*sum_alpha_pa/tau_alpha
    alpha <- rnorm(1, m, sqrt(v2))
    
    return(alpha)
}

## udpate beta
fn_update_alpha <- function(n, tau_alpha, P_alpha, sum_alpha_pa)
{
    v2 <- 1/(n/tau_alpha + 1.0/P_alpha)
    m <- v2*sum_alpha_pa/tau_alpha
    alpha <- rnorm(1, m, sqrt(v2))
    
    return(alpha)
}

## update tau_alpha, tau_beta, sig2
fn_update_tau <- function(a, b, n, sum_sq_dev)
{
    aa <- a + n/2.0
    bb <- b + sum_sq_dev/2.0
    tau <- rgamma(1, aa, bb)
    
    return(1/tau)
}


## update alpha_i or beta_i
fn_update_alpha_pa <- function(pa, m, n, tau_alpha, sig2, alpha, res)
{
    ## pa <- dat$pa; m <- dat$m; n <- dat$n; tau_alpha <- cur_sam$tau_alpha; sig2 <- cur_sam$sig2; alpha <- cur_sam$alpha; res <- (dat$y - cur_sam$beta_pa[dat$pa]*dat$x)
    tmp <- as.data.frame(cbind(res, pa))
    tmp <- aggregate(tmp$res, by=list(tmp$pa), FUN=sum, na.rm=TRUE)$x

    v2 <- 1/(1/tau_alpha + m/sig2)
    m <- v2*(alpha/tau_alpha + tmp/sig2)
    alpha_pa <- rnorm(n, m, sqrt(v2))

    return(alpha_pa)
}

