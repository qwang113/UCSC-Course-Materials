rm(list=ls(all=TRUE))
set.seed(4444)
library(MASS)

# read data and calculate statistics
x <- read.table("/Volumes/MY PASSPORT/UCSC/Teaching/stat206B-ams206b/2022/hw/hw4/sol/Q-2/my-data.txt", header=FALSE)[,1]
n <- length(x)
sum.x <- sum(x)
sum.log.x <-sum(log(x))

### hyperparameters
alpha <- 2
beta <- 2
a <- 3
b <- 1


# call the library coda for autocorrelation plots
library(coda)

# call the library for the multivariate normal
library(mvtnorm)

# set up
N.test <- 6000

sam <- NULL
sam$th <-rep(NA, N.test)
sam$nu <-rep(NA, N.test)


# set variance of the proposal for test run
V <- 0.04 * diag(2)

# initial values
th.cur <- 2
nu.cur <- 3

for (i.sam in 1:N.test) {
    
    # propose (nu, theta) jointly from a Random Walk
    nu.pro <- exp(log(nu.cur) + rnorm(1, 0, sqrt(V[1, 1])))
    th.pro <- exp(log(th.cur) + rnorm(1, 0, sqrt(V[2, 2])))
    
    # evaluate the joint target density (on the log scale) at the current value + jacobian
    p.cur <- (n*nu.cur + alpha)*log(th.cur) - n*lgamma(nu.cur) + nu.cur*(sum.log.x - b) + a*log(nu.cur) - th.cur*(beta + sum.x)
    
    # evaluate the joint target density (on the log scale) at the proposed value + jacobian
    p.pro <- (n*nu.pro + alpha)*log(th.pro) - n*lgamma(nu.pro) + nu.pro*(sum.log.x - b) + a*log(nu.pro) - th.pro*(beta + sum.x)
    
    # calculate acceptance probability and accept/reject accordingly
    accpt.prob <- exp(p.pro - p.cur)
    if (runif(1) < accpt.prob) {
        nu.cur <- nu.pro
        th.cur <- th.pro
    }
    
    # save current draw
    sam$th[i.sam] <- th.cur
    sam$nu[i.sam] <- nu.cur
}### end test run



# update variance-covariance of the proposal
V <- cov(cbind(sam$nu[1:N.test], sam$th[1:N.test]))

N.sam <- 6000
N.burn <- 3000
N.thin <- 5

sam <- NULL
sam$th <-rep(NA, N.sam)
sam$nu <-rep(NA, N.sam)

i.sam <- 1
for(i.iter in 1:(N.thin*N.sam)) {
    # propose (nu, theta) jointly from a Random Walk
    eps <- mvrnorm(1, c(0,0), V)
    th.pro <- exp(log(th.cur) + eps[1])
    nu.pro <- exp(log(nu.cur) + eps[2])
    
    # evaluate the joint target density (on the log scale) at the current value + jacobian
    p.cur <- (n*nu.cur + alpha)*log(th.cur) - n*lgamma(nu.cur) + nu.cur*(sum.log.x - b) + a*log(nu.cur) - th.cur*(beta + sum.x)
    
    # evaluate the joint target density (on the log scale) at the proposed value + jacobian
    p.pro <- (n*nu.pro + alpha)*log(th.pro) - n*lgamma(nu.pro) + nu.pro*(sum.log.x - b) + a*log(nu.pro) - th.pro*(beta + sum.x)
    
    # calculate acceptance probability and accept/reject accordingly
    accpt.prob <- exp(p.pro - p.cur)
    if (runif(1) < accpt.prob) {
        nu.cur <- nu.pro
        th.cur <- th.pro
    }
    
    # save current draw
    if((i.iter%%N.thin)==0)
    {
        # save current draw
        sam$th[i.sam] <- th.cur
        sam$nu[i.sam] <- nu.cur
        i.sam <- i.sam + 1
    }## if((i.iter%%N.thin)==0)
    
} ## for(i.sam in 1:N.sam) {


sam_1 <- NULL
sam_1$th <- sam$th[-(1:N.burn)]
sam_1$nu <- sam$nu[-(1:N.burn)]

# find effective sample size
effectiveSize(sam_1$th)
effectiveSize(sam_1$nu)


c(mean(sam_1$th), quantile(sam_1$th, probs=c(0.025, 0.975)))
c(mean(sam_1$nu), quantile(sam_1$nu, probs=c(0.025, 0.975)))


# traceplots
pdf("trace-th.pdf")
par(mar=c(4.5, 4.5, 2.1, 2.1))
plot(sam$th, col=1, type="l", main="", cex.axis=1.5, cex.lab=1.5, ylab="th")
dev.off()

pdf("trace-nu.pdf")
par(mar=c(4.5, 4.5, 2.1, 2.1))
plot(sam$nu, col=1, type="l", main="", cex.axis=1.5, cex.lab=1.5, ylab="nu")
dev.off()

# autocorrelation plots
pdf("auto-th.pdf")
par(mar=c(4.5, 4.5, 2.1, 2.1))
autocorr.plot(sam$th, col=1, lwd=4, cex.axis=1.5, cex.lab=1.5, auto.layout = FALSE, main="")
dev.off()

pdf("auto-nu.pdf")
par(mar=c(4.5, 4.5, 2.1, 2.1))
autocorr.plot(sam$nu, col=1, lwd=4, cex.axis=1.5, cex.lab=1.5, auto.layout = FALSE, main="")
dev.off()
