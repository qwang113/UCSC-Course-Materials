rm(list=ls(all=TRUE))
set.seed(4444)

# call the library coda for autocorrelation plots
library(coda)

# call the library for the multivariate normal
library(mvtnorm)
library(MASS)


# read data and calculate statistics
x <- read.table("/Volumes/MY PASSPORT/UCSC/Teaching/stat206B-ams206b/2022/hw/hw4/sol/Q-2/my-data.txt", header=FALSE)[,1]
n <- length(x)
sum.x <- sum(x)
sum.log.x <-sum(log(x))

### hyperparameters
alpha <- 2
beta <- 2
a <- 3
b <- 1


# Define the function to optimize
h <- function(w) {
    r <- exp(w[2]) * (sum.log.x - b) + a*w[2]
    r <- r - n*lgamma(exp(w[2])) + (alpha + n*exp(w[2]))*w[1] - exp(w[1])*(beta + sum.x)
    return(-r)
}

# Obtain the maximum and the Hessian at the maximum
lap <- optim(c(0, 1), h, hessian = TRUE)

# Optimum
lap$par

# Hessian
lap$hessian

mode0 <- c(lap$par[1], lap$par[2])


# initial values
th.cur <- exp(mode0[1])
nu.cur <- exp(mode0[2])


# update variance-covariance of the proposal
V <- solve(lap$hessian)
inv_V <- solve(V)

N.sam <- 6000
N.burn <- 3000
N.thin <- 5

sam <- NULL
sam$th <-rep(NA, N.sam)
sam$nu <-rep(NA, N.sam)

i.sam <- 1

for(i.iter in 1:(N.thin*N.sam)) {
    # propose (nu, theta) jointly
    eps <- mvrnorm(1, mode0, V)
    th.pro <- exp(eps[1])
    nu.pro <- exp(eps[2])
        
    # evaluate the joint target density (on the log scale) at the current value  + proposal density
    p.cur <- (n*nu.cur + alpha)*log(th.cur) - n*lgamma(nu.cur) + nu.cur*(sum.log.x - b) + a*log(nu.cur) - th.cur*(beta + sum.x) - 1/2*t(mode0 - eps)%*%inv_V%*%(mode0 - eps)
    
    # evaluate the joint target density (on the log scale) at the proposed value   + proposal density
    p.pro <- (n*nu.pro + alpha)*log(th.pro) - n*lgamma(nu.pro) + nu.pro*(sum.log.x - b) + a*log(nu.pro) - th.pro*(beta + sum.x) - 1/2*t(mode0 - log(c(th.cur, nu.cur)))%*%inv_V%*%(mode0 - log(c(th.cur, nu.cur)))
    
    print(c(i.iter, p.cur, p.pro))
    
    # calculate acceptance probability and accept/reject accordingly
    accpt.prob <- exp(p.pro - p.cur)
    if (runif(1) < accpt.prob) {
        nu.cur <- nu.pro
        th.cur <- th.pro
        
        print("accpt")
        
    }
    
    # save current draw
    if((i.iter%%N.thin)==0)
    {
        # save current draw
        sam$th[i.sam] <- th.cur
        sam$nu[i.sam] <- nu.cur
        i.sam <- i.sam + 1
    }## if((i.iter%%N.thin)==0)
    
} ## for(i.sam in 1:N.sam) {



sam_1 <- NULL
sam_1$th <- sam$th[-(1:N.burn)]
sam_1$nu <- sam$nu[-(1:N.burn)]

# find effective sample size
effectiveSize(sam_1$th)
effectiveSize(sam_1$nu)


c(mean(sam_1$th), quantile(sam_1$th, probs=c(0.025, 0.975)))
c(mean(sam_1$nu), quantile(sam_1$nu, probs=c(0.025, 0.975)))


# traceplots
pdf("trace-th.pdf")
par(mar=c(4.5, 4.5, 2.1, 2.1))
plot(sam$th, col=1, type="l", main="", cex.axis=1.5, cex.lab=1.5, ylab="th")
dev.off()

pdf("trace-nu.pdf")
par(mar=c(4.5, 4.5, 2.1, 2.1))
plot(sam$nu, col=1, type="l", main="", cex.axis=1.5, cex.lab=1.5, ylab="nu")
dev.off()

# autocorrelation plots
pdf("auto-th.pdf")
par(mar=c(4.5, 4.5, 2.1, 2.1))
autocorr.plot(sam$th, col=1, lwd=4, cex.axis=1.5, cex.lab=1.5, auto.layout = FALSE, main="")
dev.off()

pdf("auto-nu.pdf")
par(mar=c(4.5, 4.5, 2.1, 2.1))
autocorr.plot(sam$nu, col=1, lwd=4, cex.axis=1.5, cex.lab=1.5, auto.layout = FALSE, main="")
dev.off()
