rm(list=ls(all=TRUE))
set.seed(4444)

# read data and calculate statistics
x <- read.table("/Volumes/MY PASSPORT/UCSC/Teaching/stat206B-ams206b/2022/hw/hw4/sol/Q-2/my-data.txt", header=FALSE)[,1]
n <- length(x)
sum.x <- sum(x)
sum.log.x <-sum(log(x))

### hyperparameters
alpha <- 2
beta <- 2
a <- 3
b <- 1


# call the library coda for autocorrelation plots
library(coda)

# call the library for the multivariate normal
library(mvtnorm)

# set up - MCMC parameters
N.sam <- 6000
N.burn <- 3000
N.thin <- 5

## save MC samples
sam <- NULL
sam$th <-rep(NA, N.sam)
sam$nu <-rep(NA, N.sam)

# set the variance of a RW proposal of \nu
v <- 0.5


# initial values
th.cur <- 2
nu.cur <- 3

### do sampling
i.sam <- 1
for(i.iter in 1:(N.thin*N.sam))
{
    # update theta using Gibbs step
    th.cur <- rgamma(1, n*nu.cur + alpha, beta + sum.x)
    
    #### BEGIN: Update \nu using MH with RW
    # get proposed value for nu using a Random Walk proposal on log scale
    nu.pro <- exp(log(nu.cur) + rnorm(1, 0, sqrt(v)))
    
    # evaluate target pdf at current value + Jacobian
    p.nu.cur <- nu.cur*(sum.log.x + n*log(th.cur) - b) - n*lgamma(nu.cur) + a*log(nu.cur)
    
    # evaluate target pdf at proposed value
    p.nu.pro <- nu.pro*(sum.log.x + n*log(th.cur) - b) - n*lgamma(nu.pro) + a*log(nu.pro)
    
    # calculate acceptance probability and accept/reject accordingly
    accpt.prob <- exp(p.nu.pro - p.nu.cur)
    if(runif(1) < accpt.prob)
    {
        nu.cur <- nu.pro
    }
    #### END: Update \nu using MH with RW

    
    
    if((i.iter%%N.thin)==0)
    {
        # save current draw
        sam$th[i.sam] <- th.cur
        sam$nu[i.sam] <- nu.cur
        i.sam <- i.sam + 1
    }
    
} ## for(i.sam in 1:N.sam) {

sam_1 <- NULL
sam_1$th <- sam$th[-(1:N.burn)]
sam_1$nu <- sam$nu[-(1:N.burn)]

# find effective sample size
effectiveSize(sam_1$th)
effectiveSize(sam_1$nu)


c(mean(sam_1$th), quantile(sam_1$th, probs=c(0.025, 0.975)))
c(mean(sam_1$nu), quantile(sam_1$nu, probs=c(0.025, 0.975)))


# traceplots
pdf("trace-th.pdf")
par(mar=c(4.5, 4.5, 2.1, 2.1))
plot(sam$th, col=1, type="l", main="", cex.axis=1.5, cex.lab=1.5, ylab="th")
dev.off()

pdf("trace-nu.pdf")
par(mar=c(4.5, 4.5, 2.1, 2.1))
plot(sam$nu, col=1, type="l", main="", cex.axis=1.5, cex.lab=1.5, ylab="nu")
dev.off()

# autocorrelation plots
pdf("auto-th.pdf")
par(mar=c(4.5, 4.5, 2.1, 2.1))
autocorr.plot(sam$th, col=1, lwd=4, cex.axis=1.5, cex.lab=1.5, auto.layout = FALSE, main="")
dev.off()

pdf("auto-nu.pdf")
par(mar=c(4.5, 4.5, 2.1, 2.1))
autocorr.plot(sam$nu, col=1, lwd=4, cex.axis=1.5, cex.lab=1.5, auto.layout = FALSE, main="")
dev.off()
